package com.example.jlenag2_378_projecttwo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
