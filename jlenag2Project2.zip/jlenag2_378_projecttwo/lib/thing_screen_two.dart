import 'package:flutter/material.dart';
//Coded by Joseph Lenaghan, Project Two for CS 378 at UIC | UIN :676805596 | 11/5/22



class ThingScreenTwo extends StatelessWidget {
  const ThingScreenTwo ({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        elevation: 15,
        toolbarHeight: 90,
        backgroundColor: Colors.blueGrey,
        shadowColor: Colors.black,
        shape:  RoundedRectangleBorder(
          borderRadius: BorderRadius.horizontal(
              left: Radius.circular(10),
              right: Radius.circular(10)
          ),
        ),
        flexibleSpace: FlexibleSpaceBar(
            title: Text(
              'A Night at the Movies',
              style: TextStyle(
                color: Colors.white,
                shadows: <Shadow>[
                  Shadow(
                    offset: Offset(1,1),
                    color: Colors.black,
                  )
                ],
              ),
            ),
            background: Image.asset('images/popcorn.jpg')
        ),
      ),
      body: Center(

          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                    height: 30,
                    width: 230,
                    margin: EdgeInsets.all(10),
                    child: Text('This film was directed by John Carpenter')
                ),
                Container(
                    margin: EdgeInsets.all(10),
                    child: Column(
                        children: [
                          Text("Stars featured in this film:"),
                          Text('Kurt Russell'),
                          Text('Wilford Brimley'),
                          Text('Keith David'),
                        ]
                    )
                ),
                Container(
                    margin: EdgeInsets.all(10),
                    child: Column(
                        children: [
                          Text('Runtime: 1 hour, 49 minutes'),
                          Text('Rated 8 out of 10 stars')
                        ]
                    )
                ),
                Container(
                    height: 100,
                    width: 300,
                    margin: EdgeInsets.all(10),
                    child: Text('Dave Kehr of the Chicago Reader describes it, saying "Carpenter\'s direction is slow\, dark\, and stately\; he seems to be aiming for an enveloping novelistic kind of effect, but all he gets is heaviness" ')
                ),
                Container(
                    height: 100,
                    width: 300,
                    margin: EdgeInsets.all(10),
                    child: Text('Adam Smith of Empire Magazine says "The Thing is a peerless masterpiece of relentless suspense, retina-wrecking visual excess and outright, nihilistic terror." ')
                ),
              ]
          )
      ),
    );
  }
}
