import 'package:flutter/material.dart';
import 'package:jlenag2_378_projecttwo/poetic_screen_one.dart';
import 'package:jlenag2_378_projecttwo/poetic_screen_two.dart';
import 'package:jlenag2_378_projecttwo/psycho_screen_one.dart';
import 'package:jlenag2_378_projecttwo/psycho_screen_two.dart';
import 'package:jlenag2_378_projecttwo/pulp_screen_one.dart';
import 'package:jlenag2_378_projecttwo/pulp_screen_two.dart';
import 'package:jlenag2_378_projecttwo/sicario_screen_one.dart';
import 'package:jlenag2_378_projecttwo/sicario_screen_two.dart';
import 'package:jlenag2_378_projecttwo/taxi_screen_one.dart';
import 'package:jlenag2_378_projecttwo/taxi_screen_two.dart';
import 'package:jlenag2_378_projecttwo/thing_screen_one.dart';
import 'package:jlenag2_378_projecttwo/thing_screen_two.dart';
import 'package:jlenag2_378_projecttwo/thirteen_screen_one.dart';
import 'package:jlenag2_378_projecttwo/thirteen_screen_two.dart';
import 'package:url_launcher/url_launcher.dart';
import 'alien_screen_one.dart';
import 'alien_screen_two.dart';
import 'baked_screen_one.dart';
import 'baked_screen_two.dart';
import 'borat_screen_one.dart';
import 'borat_screen_two.dart';
import 'dude_screen_one.dart';
import 'dude_screen_two.dart';
import 'enter_screen_one.dart';
import 'enter_screen_two.dart';
import 'ghost_screen_one.dart';
import 'ghost_screen_two.dart';
import 'mail_screen_one.dart';
import 'mail_screen_two.dart';
import 'mummy_screen_one.dart';
import 'mummy_screen_two.dart';
//Coded by Joseph Lenaghan, Project Two for CS 378 at UIC | UIN :676805596 | 11/5/22
// list of all the URI's needed for this project!!!
final Uri _thirteen = Uri.parse('https://www.imdb.com/title/tt0245674/');
final Uri _thirteenWiki = Uri.parse('https://en.wikipedia.org/wiki/Thirteen_Ghosts');
final Uri _thing = Uri.parse('https://www.imdb.com/title/tt0084787/');
final Uri _thingWiki = Uri.parse('https://en.wikipedia.org/wiki/The_Thing_(1982_film)');
final Uri _alien = Uri.parse('https://www.imdb.com/title/tt0078748/');
final Uri _alienWiki = Uri.parse('https://en.wikipedia.org/wiki/Alien_(film)');
final Uri _mummy = Uri.parse('https://www.imdb.com/title/tt0120616/');
final Uri _mummyWiki = Uri.parse('https://en.wikipedia.org/wiki/The_Mummy_(1999_film)');
final Uri _sicario = Uri.parse('https://www.imdb.com/title/tt3397884/');
final Uri _sicarioWiki = Uri.parse('https://en.wikipedia.org/wiki/Sicario_(2015_film)');
final Uri _enter = Uri.parse('https://www.imdb.com/title/tt0070034/');
final Uri _enterWiki = Uri.parse('https://en.wikipedia.org/wiki/Enter_the_Dragon');
final Uri _borat = Uri.parse('https://www.imdb.com/title/tt0443453/');
final Uri _boratWiki = Uri.parse('https://en.wikipedia.org/wiki/Borat');
final Uri _dude = Uri.parse('https://www.imdb.com/title/tt0242423/');
final Uri _dudeWiki = Uri.parse('https://en.wikipedia.org/wiki/Dude,_Where%27s_My_Car%3F');
final Uri _baked = Uri.parse('https://www.imdb.com/title/tt0120693/');
final Uri _bakedWiki = Uri.parse('https://en.wikipedia.org/wiki/Half_Baked');
final Uri _psycho = Uri.parse('https://www.imdb.com/title/tt0144084/');
final Uri _psychoWiki = Uri.parse('https://en.wikipedia.org/wiki/American_Psycho_(film)');
final Uri _pulp = Uri.parse('https://www.imdb.com/title/tt0110912/');
final Uri _pulpWiki = Uri.parse('https://en.wikipedia.org/wiki/Pulp_Fiction');
final Uri _taxi = Uri.parse('https://www.imdb.com/title/tt0075314/');
final Uri _taxiWiki = Uri.parse('https://en.wikipedia.org/wiki/Taxi_Driver');
final Uri _mail = Uri.parse('https://www.imdb.com/title/tt0128853/');
final Uri _mailWiki = Uri.parse('https://en.wikipedia.org/wiki/You%27ve_Got_Mail');
final Uri _poetic = Uri.parse('https://www.imdb.com/title/tt0107840/');
final Uri _poeticWiki = Uri.parse('https://en.wikipedia.org/wiki/Poetic_Justice_(film)');
final Uri _ghost = Uri.parse('https://www.imdb.com/title/tt0099653/');
final Uri _ghostWiki = Uri.parse('https://en.wikipedia.org/wiki/Ghost_(1990_film)');
// end of urls used for this project

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      routes: {
        '/horrorOne': (context) => const ThirteenScreen(),
        '/horrorTwo': (context) => const ThingScreen(),
        '/horrorThree': (context) => const AlienScreen(),
        '/actionOne': (context) => const MummyScreen(),
        '/actionTwo': (context) => const SicarioScreen(),
        '/actionThree': (context) => const EnterScreen(),
        '/comedyOne': (context) => const BoratScreen(),
        '/comedyTwo': (context) => const DudeScreen(),
        '/comedyThree':(context) => const BakedScreen(),
        '/thrillerOne':(context) => const PsychoScreen(),
        '/thrillerTwo':(context) => const PulpScreen(),
        '/thrillerThree':(context) => const TaxiScreen(),
        '/romanceOne':(context) => const MailScreen(),
        '/romanceTwo':(context) => const PoeticScreen(),
        '/romanceThree':(context) => const GhostScreen(),
        '/horrorInfoOne':(context) => const ThirteenScreenTwo(),
        '/horrorInfoTwo':(context) => const ThingScreenTwo(),
        '/horrorInfoThree':(context) => const AlienScreenTwo(),
        '/actionInfoOne':(context) => const MummyScreenTwo(),
        '/actionInfoTwo':(context) => const SicarioScreenTwo(),
        '/actionInfoThree':(context) => const EnterScreenTwo(),
        '/comedyInfoOne':(context) => const BoratScreenTwo(),
        '/comedyInfoTwo':(context) => const DudeScreenTwo(),
        '/comedyInfoThree':(context) => const BakedScreenTwo(),
        '/thrillerInfoOne':(context) => const PsychoScreenTwo(),
        '/thrillerInfoTwo':(context) => const PulpScreenTwo(),
        '/thrillerInfoThree':(context) => const TaxiScreenTwo(),
        '/romanceInfoOne':(context) => MailScreenTwo(),
        '/romanceInfoTwo':(context) => PoeticScreenTwo(),
        '/romanceInfoThree':(context) => GhostScreenTwo()


      },
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;


  final List<String> horror_movies = const [
    "Thirteen Ghosts",
    "The Thing (1982)",
    "Alien"
  ]; // list that will be called by the item builder to get the titles for a list tile

  final List<String> horror_subs = const [
    "Directed by Steve Beck  Released in 2001",
    "Directed by John Carpenter  Released in 1982",
    "Directed by Ridley Scott  Released in 1979"
  ]; // list that will be called by the item builder to get a subtitle for a list tile

  final List<String> horror_pics = const [
    "images/thirteen.jpg",
    "images/thing.jpg",
    "images/alien.jpg",
  ]; // list that will be called by the item builder to get the relevant image for a list tile

  final List<String> act_and_adv_movies = const [
    "The Mummy",
    "Sicario",
    "Enter the Dragon"
  ]; // list that will be called by the item builder to get the titles for a list tile

  final List<String> act_and_adv_subs = const [
    "Directed by Stephen Sommers Released in 1999",
    "Directed by Denis Villeneuve Released in 2015",
    "Directed by Robert Clouse Released in 1973"
  ]; // list that will be called by the item builder to get a subtitle for a list tile

  final List<String> act_and_adv_pics = const [
    "images/mummy.jpg",
    "images/sicario.jpg",
    "images/enter.jpg"
  ]; // list that will be called by the item builder to get the relevant image for a list tile


  final List<String> comedy_movies = const [
    "Borat",
    "Dude, Where's my Car?",
    "Half Baked"
  ]; // list that will be called by the item builder to get the titles for a list tile

  final List<String> comedy_subs = const [
    "Directed by Larry Charles Released in 2006",
    "Directed by Danny Leiner Released in 2000",
    "Directed by Tamra Davis Released in 1998"
  ]; // list that will be called by the item builder to get a subtitle for a list tile

  final List<String> comedy_pics = const [
    "images/borat.jpg",
    "images/dude.jpg",
    "images/baked.jpg"
  ]; // list that will be called by the item builder to get the relevant image for a list tile


  final List<String> thriller_movies = const [
    "American Psycho",
    "Pulp Fiction",
    "Taxi Driver"
  ]; // list that will be called by the item builder to get the titles for a list tile

  final List<String> thriller_subs = const [
    "Directed by Mary Harron Released in 2000",
    "Directed by Quentin Tarantino Released in 1994",
    "Directed by Martin Scorsese Released in 1976"
  ]; // list that will be called by the item builder to get a subtitle for a list tile

  final List<String> thriller_pics = const [
    "images/psycho.jpg",
    "images/pulp.jpg",
    "images/taxi.jpg"
  ]; // list that will be called by the item builder to get the relevant image for a list tile

  final List<String> romance_movies = const [
    "You've Got Mail",
    "Poetic Justice",
    "Ghost"
  ]; // list that will be called by the item builder to get the titles for a list tile

  final List<String> romance_subs = const [
    "Directed by Nora Ephron Released in 1998",
    "Directed by John Singleton Released in 1993",
    "Directed By Jerry Zucker Released in 1990"
  ]; // list that will be called by the item builder to get a subtitle for a list tile

  final List<String> romance_pics = const [
    "images/mail.jpg",
    "images/poetic.jpeg",
    "images/ghost.jpeg"
  ]; // list that will be called by the item builder to get the relevant image for a list tile

  @override
  State<MyHomePage> createState() => _MyHomePageState();

}

class _MyHomePageState extends State<MyHomePage> {

  @override
  Widget build(BuildContext context) {

    return  Scaffold(
      backgroundColor: Colors.grey,
      body: CustomScrollView(
        slivers: <Widget>[
          SliverAppBar( // app bar requested in the write-up
            pinned: true,
            expandedHeight: 145,
            elevation: 15,
            backgroundColor: Colors.blueGrey,
            shadowColor: Colors.black,
            shape:  RoundedRectangleBorder(
              borderRadius: BorderRadius.horizontal(
                left: Radius.circular(10),
                right: Radius.circular(10)
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                'A Night at the Movies', // title of the app bar
                style: TextStyle(
                  color: Colors.white,
                  shadows: <Shadow>[
                    Shadow(
                      offset: Offset(1,1),
                      color: Colors.black,
                    )
                  ],
                ),
              ),
              background: Image.asset('images/popcorn.jpg') // providing an image
            ),
          ),

          //every app bar after this line denotes a list of movies
          // beginning of horror appbar
          SliverAppBar(
            pinned: true,
            elevation: 15,
            backgroundColor: Colors.purple,
            expandedHeight: 25,
            shadowColor: Colors.black,
            toolbarHeight: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.horizontal(
                  left: Radius.circular(5),
                  right: Radius.circular(5),
              ),

            ),
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                'Horror', // title of the appbar
                style: TextStyle(
                  fontSize: 30,
                  shadows: <Shadow>[
                    Shadow(
                      offset: Offset(1,1),
                      color: Colors.black,
                    )
                  ],
                ),
              ),
              centerTitle: true,
            ),
          ),
          //end of horror appbar

          //horror movie list
          SliverToBoxAdapter(
            child: Container(
              height: 200,
              color: Colors.grey,
              child: ListView.builder( // builder builds each item of the list
                scrollDirection: Axis.horizontal,
                itemCount: widget.horror_movies.length,
                itemBuilder: (BuildContext context, int index){ // builder builds the contents of each item
                  return Container(
                    width: 300,
                    height: 200,
                    margin: EdgeInsets.all(4.0),
                    decoration: BoxDecoration(
                      color: Colors.blueGrey,
                      borderRadius: BorderRadius.circular(25)
                    ),
                      child: ListTile( // List tile that will hold the thumbnail, title, and subtitle, has onTap() and onLongPress() functionality
                          leading: Image(
                            image: AssetImage(widget.horror_pics[index]),
                          ),
                          title: Text(
                              widget.horror_movies[index],
                              style: TextStyle(
                                fontSize: 25
                              )
                          ),
                          subtitle: Text(
                              widget.horror_subs[index],
                          ),
                          onTap: () { // on tap functionality for list tile opens up the relevant activity based on the index of the list tile
                            if(index == 0) {
                              Navigator.pushNamed(context, '/horrorOne');
                            }
                            else if(index == 1){
                              Navigator.pushNamed(context, '/horrorTwo');
                            }
                            else{
                              Navigator.pushNamed(context, '/horrorThree');
                            }
                          },
                        onLongPress: () { // on long press functionality uses a snackbar to get buttons for the user to click
                          final snackBar = SnackBar(
                            content: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Card( // this menu option will take the user to the info page about the movie
                                  color: Colors.grey,
                                  margin: EdgeInsets.all(40),
                                  child : Container(
                                    height: 50,
                                    width: 200,
                                    margin: EdgeInsets.all(10),
                                    color: Colors.blueGrey,
                                    child: TextButton(
                                      child: Text('Learn More About This Film'),
                                      onPressed: () {
                                        if(index == 0){
                                          Navigator.pushNamed(context, '/horrorInfoOne');
                                          ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                        }
                                        else if(index == 1){
                                          Navigator.pushNamed(context, '/horrorInfoTwo');
                                          ScaffoldMessenger.of(context).hideCurrentSnackBar();

                                        }
                                        else{
                                          Navigator.pushNamed(context, '/horrorInfoThree');
                                          ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                        }
                                      }
                                    )
                                ),
                                ),
                                Card( // this menu option opens a browser containing the wiki page about the relevant film
                                  color: Colors.grey,
                                  margin: EdgeInsets.all(40),
                                  child : Container(
                                      height: 50,
                                      width: 200,
                                      margin: EdgeInsets.all(10),
                                      color: Colors.blueGrey,
                                      child: TextButton(
                                          child: Text('View the Wikipedia Page'),
                                          onPressed: () {
                                            if(index == 0){
                                              launchUrl(_thirteenWiki);
                                              ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                            }
                                            else if(index == 1){
                                              launchUrl(_thingWiki);
                                              ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                            }
                                            else{
                                              launchUrl(_alienWiki);
                                              ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                            }
                                          }
                                      )
                                  ),
                                ),
                                Card(  // this menu option takes the user to the imdb page like the short press
                                  color: Colors.grey,
                                  margin: EdgeInsets.all(40),
                                  child : Container(
                                      height: 50,
                                      width: 200,
                                      margin: EdgeInsets.all(10),
                                      color: Colors.blueGrey,
                                      child: TextButton(
                                          child: Text('Visit the IMDB Page'),
                                          onPressed: () {
                                            if(index == 0){
                                              launchUrl(_thirteen);
                                              ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                            }
                                            else if(index == 1){
                                              launchUrl(_thing);
                                              ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                            }
                                            else{
                                              launchUrl(_alien);
                                              ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                            }
                                          }
                                      )
                                  ),
                                ),
                              ]
                            )
                          );
                          ScaffoldMessenger.of(context)
                              .showSnackBar(snackBar);
                        },
                      )
                  );
                }
              )
            )
          ),
          //end of horror movie list

          //beginning of action and adventure appbar
          SliverAppBar(
            pinned: true,
            elevation: 15,
            backgroundColor: Colors.green,
            expandedHeight: 25,
            shadowColor: Colors.black,
            toolbarHeight: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.horizontal(
                left: Radius.circular(5),
                right: Radius.circular(5),
              ),

            ),
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                'Action & Adventure', // title of the appbar
                style: TextStyle(
                  fontSize: 30,
                  shadows: <Shadow>[
                    Shadow(
                      offset: Offset(1,1),
                      color: Colors.black,
                    )
                  ],
                ),
              ),
              centerTitle: true,
            ),
          ),
          //end of action and adventure appbar

          //beginning of action and adventure list
          SliverToBoxAdapter(
              child: Container(
                  height: 200,
                  color: Colors.grey,
                  child: ListView.builder( // builder builds each item of the list
                      scrollDirection: Axis.horizontal,
                      itemCount: widget.act_and_adv_movies.length,
                      itemBuilder: (BuildContext context, int index){ // builder builds the contents of each item
                        return Container(
                          width: 300,
                          height: 200,
                          margin: EdgeInsets.all(4.0),
                          decoration: BoxDecoration(
                              color: Colors.blueGrey,
                              borderRadius: BorderRadius.circular(25)
                          ),
                            child: ListTile( // List tile that will hold the thumbnail, title, and subtitle, has onTap() and onLongPress() functionality
                                leading: Image(
                                  image: AssetImage(widget.act_and_adv_pics[index]),
                                ),
                                title: Text(
                                    widget.act_and_adv_movies[index],
                                    style: TextStyle(
                                        fontSize: 25
                                    )
                                ),
                                subtitle: Text(
                                  widget.act_and_adv_subs[index],
                                ),
                                onTap: () { // on tap functionality for list tile opens up the relevant activity based on the index of the list tile
                                  if(index == 0) {
                                    Navigator.pushNamed(context, '/actionOne');
                                  }
                                  else if(index == 1){
                                    Navigator.pushNamed(context, '/actionTwo');
                                  }
                                  else{
                                    Navigator.pushNamed(context, '/actionThree');
                                  }
                                },
                              onLongPress: () { // on long press functionality uses a snackbar to get buttons for the user to click
                                final snackBar = SnackBar(
                                    content: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Card( // this menu option will take the user to the info page about the movie
                                            color: Colors.grey,
                                            margin: EdgeInsets.all(40),
                                            child : Container(
                                                height: 50,
                                                width: 200,
                                                margin: EdgeInsets.all(10),
                                                color: Colors.blueGrey,
                                                child: TextButton(
                                                    child: Text('Learn More About This Film'),
                                                    onPressed: () {
                                                      if(index == 0){
                                                        Navigator.pushNamed(context, '/actionInfoOne');
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else if(index == 1){
                                                        Navigator.pushNamed(context, '/actionInfoTwo');
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();

                                                      }
                                                      else{
                                                        Navigator.pushNamed(context, '/actionInfoThree');
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                    }
                                                )
                                            ),
                                          ),
                                          Card( // this menu option opens a browser containing the wiki page about the relevant film
                                            color: Colors.grey,
                                            margin: EdgeInsets.all(40),
                                            child : Container(
                                                height: 50,
                                                width: 200,
                                                margin: EdgeInsets.all(10),
                                                color: Colors.blueGrey,
                                                child: TextButton(
                                                    child: Text('View the Wikipedia Page'),
                                                    onPressed: () {
                                                      if(index == 0){
                                                        launchUrl(_mummyWiki);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else if(index == 1){
                                                        launchUrl(_sicarioWiki);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else{
                                                        launchUrl(_enterWiki);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                    }
                                                )
                                            ),
                                          ),
                                          Card(  // this menu option takes the user to the imdb page like the short press
                                            color: Colors.grey,
                                            margin: EdgeInsets.all(40),
                                            child : Container(
                                                height: 50,
                                                width: 200,
                                                margin: EdgeInsets.all(10),
                                                color: Colors.blueGrey,
                                                child: TextButton(
                                                    child: Text('Visit the IMDB Page'),
                                                    onPressed: () {
                                                      if(index == 0){
                                                        launchUrl(_mummy);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else if(index == 1){
                                                        launchUrl(_sicario);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else{
                                                        launchUrl(_enter);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                    }
                                                )
                                            ),
                                          ),
                                        ]
                                    )
                                );
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(snackBar);
                              },
                            )
                        );
                      }
                  )
              )
          ),
          //end of action and adventure list

          //beginning of comedy appbar
          SliverAppBar(
            pinned: true,
            elevation: 15,
            backgroundColor: Colors.yellow,
            expandedHeight: 25,
            shadowColor: Colors.black,
            toolbarHeight: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.horizontal(
                left: Radius.circular(5),
                right: Radius.circular(5),
              ),

            ),
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                'Comedy', // title of the appbar
                style: TextStyle(
                  fontSize: 30,
                  shadows: <Shadow>[
                    Shadow(
                      offset: Offset(1,1),
                      color: Colors.black,
                    )
                  ],
                ),
              ),
              centerTitle: true,
            ),
          ),
          //end of comedy appbar

          //beginning of comedy list
          SliverToBoxAdapter(
              child: Container(
                  height: 200,
                  color: Colors.grey,
                  child: ListView.builder( // builder builds each item of the list
                      scrollDirection: Axis.horizontal,
                      itemCount: widget.comedy_movies.length,
                      itemBuilder: (BuildContext context, int index){ // builder builds the contents of each item
                        return Container(
                          width: 300,
                          height: 200,
                          margin: EdgeInsets.all(4.0),
                          decoration: BoxDecoration(
                              color: Colors.blueGrey,
                              borderRadius: BorderRadius.circular(25)
                          ),
                            child: ListTile( // List tile that will hold the thumbnail, title, and subtitle, has onTap() and onLongPress() functionality
                                leading: Image(
                                  image: AssetImage(widget.comedy_pics[index]),
                                ),
                                title: Text(
                                    widget.comedy_movies[index],
                                    style: TextStyle(
                                        fontSize: 25
                                    )
                                ),
                                subtitle: Text(
                                  widget.comedy_subs[index],

                                ),
                                onTap: () { // on tap functionality for list tile opens up the relevant activity based on the index of the list tile
                                  if(index == 0) {
                                    Navigator.pushNamed(context, '/comedyOne');
                                  }
                                  else if(index == 1){
                                    Navigator.pushNamed(context, '/comedyTwo');
                                  }
                                  else{
                                    Navigator.pushNamed(context, '/comedyThree');
                                  }
                                },
                              onLongPress: () { // on long press functionality uses a snackbar to get buttons for the user to click
                                final snackBar = SnackBar(
                                    content: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Card( // this menu option will take the user to the info page about the movie
                                            color: Colors.grey,
                                            margin: EdgeInsets.all(40),
                                            child : Container(
                                                height: 50,
                                                width: 200,
                                                margin: EdgeInsets.all(10),
                                                color: Colors.blueGrey,
                                                child: TextButton(
                                                    child: Text('Learn More About This Film'),
                                                    onPressed: () {
                                                      if(index == 0){
                                                        Navigator.pushNamed(context, '/comedyInfoOne');
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else if(index == 1){
                                                        Navigator.pushNamed(context, '/comedyInfoTwo');
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();

                                                      }
                                                      else{
                                                        Navigator.pushNamed(context, '/comedyInfoThree');
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                    }
                                                )
                                            ),
                                          ),
                                          Card( // this menu option opens a browser containing the wiki page about the relevant film
                                            color: Colors.grey,
                                            margin: EdgeInsets.all(40),
                                            child : Container(
                                                height: 50,
                                                width: 200,
                                                margin: EdgeInsets.all(10),
                                                color: Colors.blueGrey,
                                                child: TextButton(
                                                    child: Text('View the Wikipedia Page'),
                                                    onPressed: () {
                                                      if(index == 0){
                                                        launchUrl(_boratWiki);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else if(index == 1){
                                                        launchUrl(_dudeWiki);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else{
                                                        launchUrl(_bakedWiki);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                    }
                                                )
                                            ),
                                          ),
                                          Card(  // this menu option takes the user to the imdb page like the short press
                                            color: Colors.grey,
                                            margin: EdgeInsets.all(40),
                                            child : Container(
                                                height: 50,
                                                width: 200,
                                                margin: EdgeInsets.all(10),
                                                color: Colors.blueGrey,
                                                child: TextButton(
                                                    child: Text('Visit the IMDB Page'),
                                                    onPressed: () {
                                                      if(index == 0){
                                                        launchUrl(_borat);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else if(index == 1){
                                                        launchUrl(_dude);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else{
                                                        launchUrl(_baked);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                    }
                                                )
                                            ),
                                          ),
                                        ]
                                    )
                                );
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(snackBar);
                              },
                            )
                        );
                      }
                  )
              )
          ),
          // end of comedy list

          //beginning of thriller appbar
          SliverAppBar(
            pinned: true,
            elevation: 15,
            backgroundColor: Colors.orange,
            expandedHeight: 25,
            shadowColor: Colors.black,
            toolbarHeight: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.horizontal(
                left: Radius.circular(5),
                right: Radius.circular(5),
              ),

            ),
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                'Thriller', // title of the appbar
                style: TextStyle(
                  fontSize: 30,
                  shadows: <Shadow>[
                    Shadow(
                      offset: Offset(1,1),
                      color: Colors.black,
                    )
                  ],
                ),
              ),
              centerTitle: true,
            ),
          ),
          //end of thriller appbar

          //beginning of thriller list
          SliverToBoxAdapter(
              child: Container(
                  height: 200,
                  color: Colors.grey,
                  child: ListView.builder( // builder builds each item of the list
                      scrollDirection: Axis.horizontal,
                      itemCount: widget.thriller_movies.length,
                      itemBuilder: (BuildContext context, int index){ // builder builds the contents of each item
                        return Container(
                          width: 300,
                          height: 200,
                          margin: EdgeInsets.all(4.0),
                          decoration: BoxDecoration(
                              color: Colors.blueGrey,
                              borderRadius: BorderRadius.circular(25)
                          ),
                            child: ListTile( // List tile that will hold the thumbnail, title, and subtitle, has onTap() and onLongPress() functionality
                                leading: Image(
                                  image: AssetImage(widget.thriller_pics[index]),
                                ),
                                title: Text(
                                    widget.thriller_movies[index],
                                    style: TextStyle(
                                        fontSize: 25
                                    )
                                ),
                                subtitle: Text(
                                  widget.thriller_subs[index],
                                ),
                                onTap: () { // on tap functionality for list tile opens up the relevant activity based on the index of the list tile
                                  if(index == 0) {
                                    Navigator.pushNamed(context, '/thrillerOne');
                                  }
                                  else if(index == 1){
                                    Navigator.pushNamed(context, '/thrillerTwo');
                                  }
                                  else{
                                    Navigator.pushNamed(context, '/thrillerThree');
                                  }
                                },
                              onLongPress: () { // on long press functionality uses a snackbar to get buttons for the user to click
                                final snackBar = SnackBar(
                                    content: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Card( // this menu option will take the user to the info page about the movie
                                            color: Colors.grey,
                                            margin: EdgeInsets.all(40),
                                            child : Container(
                                                height: 50,
                                                width: 200,
                                                margin: EdgeInsets.all(10),
                                                color: Colors.blueGrey,
                                                child: TextButton(
                                                    child: Text('Learn More About This Film'),
                                                    onPressed: () {
                                                      if(index == 0){
                                                        Navigator.pushNamed(context, '/thrillerInfoOne');
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else if(index == 1){
                                                        Navigator.pushNamed(context, '/thrillerInfoTwo');
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();

                                                      }
                                                      else{
                                                        Navigator.pushNamed(context, '/thrillerInfoThree');
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                    }
                                                )
                                            ),
                                          ),
                                          Card( // this menu option opens a browser containing the wiki page about the relevant film
                                            color: Colors.grey,
                                            margin: EdgeInsets.all(40),
                                            child : Container(
                                                height: 50,
                                                width: 200,
                                                margin: EdgeInsets.all(10),
                                                color: Colors.blueGrey,
                                                child: TextButton(
                                                    child: Text('View the Wikipedia Page'),
                                                    onPressed: () {
                                                      if(index == 0){
                                                        launchUrl(_psychoWiki);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else if(index == 1){
                                                        launchUrl(_pulpWiki);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else{
                                                        launchUrl(_taxiWiki);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                    }
                                                )
                                            ),
                                          ),
                                          Card(  // this menu option takes the user to the imdb page like the short press
                                            color: Colors.grey,
                                            margin: EdgeInsets.all(40),
                                            child : Container(
                                                height: 50,
                                                width: 200,
                                                margin: EdgeInsets.all(10),
                                                color: Colors.blueGrey,
                                                child: TextButton(
                                                    child: Text('Visit the IMDB Page'),
                                                    onPressed: () {
                                                      if(index == 0){
                                                        launchUrl(_psycho);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else if(index == 1){
                                                        launchUrl(_pulp);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else{
                                                        launchUrl(_taxi);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                    }
                                                )
                                            ),
                                          ),
                                        ]
                                    )
                                );
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(snackBar);
                              },
                            )
                        );
                      }
                  )
              )
          ),
          //end of thriller list

          //beginning of romance appbar
          SliverAppBar(
            pinned: true,
            elevation: 15,
            backgroundColor: Colors.pink,
            expandedHeight: 25,
            shadowColor: Colors.black,
            toolbarHeight: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.horizontal(
                left: Radius.circular(5),
                right: Radius.circular(5),
              ),

            ),
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                'Romance', // title of the appbar
                style: TextStyle(
                  fontSize: 30,
                  shadows: <Shadow>[
                    Shadow(
                      offset: Offset(1,1),
                      color: Colors.black,
                    )
                  ],
                ),
              ),
              centerTitle: true,
            ),
          ),
          // end of romance appbar

          //beginnning of romance list
          SliverToBoxAdapter(
              child: Container(
                  height: 200,
                  color: Colors.grey,
                  child: ListView.builder( // builder builds each item of the list
                      scrollDirection: Axis.horizontal,
                      itemCount: widget.romance_movies.length,
                      itemBuilder: (BuildContext context, int index){ // builder builds the contents of each item
                        return Container(
                          width: 300,
                          height: 200,
                          margin: EdgeInsets.all(4.0),
                          decoration: BoxDecoration(
                              color: Colors.blueGrey,
                              borderRadius: BorderRadius.circular(25)
                          ),
                            child: ListTile( // List tile that will hold the thumbnail, title, and subtitle, has onTap() and onLongPress() functionality
                                leading: Image(
                                  image: AssetImage(widget.romance_pics[index]),
                                ),
                                title: Text(
                                    widget.romance_movies[index],
                                    style: TextStyle(
                                        fontSize: 25
                                    )
                                ),
                                subtitle: Text(
                                  widget.romance_subs[index],

                                ),
                                onTap: () { // on tap functionality for list tile opens up the relevant activity based on the index of the list tile
                                  if(index == 0) {
                                    Navigator.pushNamed(context, '/romanceOne');
                                  }
                                  else if(index == 1){
                                    Navigator.pushNamed(context, '/romanceTwo');
                                  }
                                  else{
                                    Navigator.pushNamed(context, '/romanceThree');
                                  }
                                },
                              onLongPress: () { // on long press functionality uses a snackbar to get buttons for the user to click
                                final snackBar = SnackBar(
                                    content: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Card( // this menu option will take the user to the info page about the movie
                                            color: Colors.grey,
                                            margin: EdgeInsets.all(40),
                                            child : Container(
                                                height: 50,
                                                width: 200,
                                                margin: EdgeInsets.all(10),
                                                color: Colors.blueGrey,
                                                child: TextButton(
                                                    child: Text('Learn More About This Film'),
                                                    onPressed: () {
                                                      if(index == 0){
                                                        Navigator.pushNamed(context, '/romanceInfoOne');
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else if(index == 1){
                                                        Navigator.pushNamed(context, '/romanceInfoTwo');
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();

                                                      }
                                                      else{
                                                        Navigator.pushNamed(context, '/romanceInfoThree');
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                    }
                                                )
                                            ),
                                          ),
                                          Card( // this menu option opens a browser containing the wiki page about the relevant film
                                            color: Colors.grey,
                                            margin: EdgeInsets.all(40),
                                            child : Container(
                                                height: 50,
                                                width: 200,
                                                margin: EdgeInsets.all(10),
                                                color: Colors.blueGrey,
                                                child: TextButton(
                                                    child: Text('View the Wikipedia Page'),
                                                    onPressed: () {
                                                      if(index == 0){
                                                        launchUrl(_mailWiki);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else if(index == 1){
                                                        launchUrl(_poeticWiki);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else{
                                                        launchUrl(_ghostWiki);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                    }
                                                )
                                            ),
                                          ),
                                          Card( // this menu option takes the user to the imdb page like the short press
                                            color: Colors.grey,
                                            margin: EdgeInsets.all(40),
                                            child : Container(
                                                height: 50,
                                                width: 200,
                                                margin: EdgeInsets.all(10),
                                                color: Colors.blueGrey,
                                                child: TextButton(
                                                    child: Text('Visit the IMDB Page'),
                                                    onPressed: () {
                                                      if(index == 0){
                                                        launchUrl(_mail);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else if(index == 1){
                                                        launchUrl(_poetic);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                      else{
                                                        launchUrl(_ghost);
                                                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                                      }
                                                    }
                                                )
                                            ),
                                          ),
                                        ]
                                    )
                                );
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(snackBar);
                              },
                            )
                        );
                      }
                  )
              )
          ),
          //end of romance list
        ]
      ),
    );
  }
}

Future<void> _launchUrl(Uri _arg) async {
  if (!await launchUrl(_arg)) {
    throw 'Could not launch $_arg';
  }
}