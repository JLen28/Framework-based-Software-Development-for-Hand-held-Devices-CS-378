import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
//Coded by Joseph Lenaghan, Project Two for CS 378 at UIC | UIN :676805596 | 11/5/22
final Uri _url = Uri.parse('https://www.imdb.com/title/tt0128853/');

class MailScreen extends StatelessWidget {
  const MailScreen({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        elevation: 15,
        toolbarHeight: 90,
        backgroundColor: Colors.blueGrey,
        shadowColor: Colors.black,
        shape:  RoundedRectangleBorder(
          borderRadius: BorderRadius.horizontal(
              left: Radius.circular(10),
              right: Radius.circular(10)
          ),
        ),
        flexibleSpace: FlexibleSpaceBar(
            title: Text(
              'A Night at the Movies',
              style: TextStyle(
                color: Colors.white,
                shadows: <Shadow>[
                  Shadow(
                    offset: Offset(1,1),
                    color: Colors.black,
                  )
                ],
              ),
            ),
            background: Image.asset('images/popcorn.jpg')
        ),
      ),
      body: Center(

          child: Column(
              children: [
                Container(
                    width: 650,
                    height:650,
                    child: TextButton(
                      child: Image.asset('images/mail.jpg'),
                      onPressed: _launchUrl,
                    )
                ),
              ]
          )
      ),
    );
  }
}

Future<void> _launchUrl() async {
  if (!await launchUrl(_url)) {
    throw 'Could not launch $_url';
  }
}