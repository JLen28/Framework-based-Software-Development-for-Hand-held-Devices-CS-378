import 'package:flutter/material.dart';
//Coded by Joseph Lenaghan, Project Two for CS 378 at UIC | UIN :676805596 | 11/5/22



class DudeScreenTwo extends StatelessWidget {
  const DudeScreenTwo ({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        elevation: 15,
        toolbarHeight: 90,
        backgroundColor: Colors.blueGrey,
        shadowColor: Colors.black,
        shape:  RoundedRectangleBorder(
          borderRadius: BorderRadius.horizontal(
              left: Radius.circular(10),
              right: Radius.circular(10)
          ),
        ),
        flexibleSpace: FlexibleSpaceBar(
            title: Text(
              'A Night at the Movies',
              style: TextStyle(
                color: Colors.white,
                shadows: <Shadow>[
                  Shadow(
                    offset: Offset(1,1),
                    color: Colors.black,
                  )
                ],
              ),
            ),
            background: Image.asset('images/popcorn.jpg')
        ),
      ),
      body: Center(

          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                    height: 30,
                    width: 230,
                    margin: EdgeInsets.all(10),
                    child: Text('This film was directed by Danny Leiner')
                ),
                Container(
                    margin: EdgeInsets.all(10),
                    child: Column(
                        children: [
                          Text("Stars featured in this film:"),
                          Text('Ashton Kutcher'),
                          Text('Seann William Scott'),
                          Text('Jennifer Garner'),
                        ]
                    )
                ),
                Container(
                    margin: EdgeInsets.all(10),
                    child: Column(
                        children: [
                          Text('Runtime: 1 hour, 23 minutes'),
                          Text('Rated 5 out of 10 stars')
                        ]
                    )
                ),
                Container(
                    height: 100,
                    width: 300,
                    margin: EdgeInsets.all(10),
                    child: Text('John Monaghan of the Detroit Free Press says "Comedies have survived with looser scenarios, but few prove as brain-dead as this one."')
                ),
                Container(
                    height: 100,
                    width: 300,
                    margin: EdgeInsets.all(10),
                    child: Text('Jessica Winter of the Village Voice reviews it as "Daft and lovable and even kinda daring, Dude deserves its truly clueless studio\'s belabored support."')
                ),
              ]
          )
      ),
    );
  }
}
