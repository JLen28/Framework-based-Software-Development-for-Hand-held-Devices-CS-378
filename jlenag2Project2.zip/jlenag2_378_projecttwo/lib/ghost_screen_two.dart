import 'package:flutter/material.dart';
//Coded by Joseph Lenaghan, Project Two for CS 378 at UIC | UIN :676805596 | 11/5/22



class GhostScreenTwo extends StatelessWidget {
  const GhostScreenTwo ({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        elevation: 15,
        toolbarHeight: 90,
        backgroundColor: Colors.blueGrey,
        shadowColor: Colors.black,
        shape:  RoundedRectangleBorder(
          borderRadius: BorderRadius.horizontal(
              left: Radius.circular(10),
              right: Radius.circular(10)
          ),
        ),
        flexibleSpace: FlexibleSpaceBar(
            title: Text(
              'A Night at the Movies',
              style: TextStyle(
                color: Colors.white,
                shadows: <Shadow>[
                  Shadow(
                    offset: Offset(1,1),
                    color: Colors.black,
                  )
                ],
              ),
            ),
            background: Image.asset('images/popcorn.jpg')
        ),
      ),
      body: Center(

          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                    height: 30,
                    width: 230,
                    margin: EdgeInsets.all(10),
                    child: Text('This film was directed by Jerry Zucker')
                ),
                Container(
                    margin: EdgeInsets.all(10),
                    child: Column(
                        children: [
                          Text("Stars featured in this film:"),
                          Text('Patrick Swayze'),
                          Text('Demi Moore'),
                          Text('Whoopi Goldberg'),
                        ]
                    )
                ),
                Container(
                    margin: EdgeInsets.all(10),
                    child: Column(
                        children: [
                          Text('Runtime: 2 hours, 47 minutes'),
                          Text('Rated 7 out of 10 stars')
                        ]
                    )
                ),
                Container(
                    height: 100,
                    width: 300,
                    margin: EdgeInsets.all(10),
                    child: Text('Henry Sheehan reviews, saying "Not only is the comedy itself fresh, but it keeps the suspense well-stropped as well."')
                ),
                Container(
                    height: 100,
                    width: 300,
                    margin: EdgeInsets.all(10),
                    child: Text('Peter Bradshaw of the Gaurdian says "Rubin\'s script is a lethally effective tragicomic fantasy."')
                ),
              ]
          )
      ),
    );
  }
}
