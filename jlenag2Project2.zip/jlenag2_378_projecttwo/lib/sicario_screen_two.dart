import 'package:flutter/material.dart';
//Coded by Joseph Lenaghan, Project Two for CS 378 at UIC | UIN :676805596 | 11/5/22



class SicarioScreenTwo extends StatelessWidget {
  const SicarioScreenTwo ({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        elevation: 15,
        toolbarHeight: 90,
        backgroundColor: Colors.blueGrey,
        shadowColor: Colors.black,
        shape:  RoundedRectangleBorder(
          borderRadius: BorderRadius.horizontal(
              left: Radius.circular(10),
              right: Radius.circular(10)
          ),
        ),
        flexibleSpace: FlexibleSpaceBar(
            title: Text(
              'A Night at the Movies',
              style: TextStyle(
                color: Colors.white,
                shadows: <Shadow>[
                  Shadow(
                    offset: Offset(1,1),
                    color: Colors.black,
                  )
                ],
              ),
            ),
            background: Image.asset('images/popcorn.jpg')
        ),
      ),
      body: Center(

          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                    height: 30,
                    width: 230,
                    margin: EdgeInsets.all(10),
                    child: Text('This film was directed by Denis Villeneuve')
                ),
                Container(
                    margin: EdgeInsets.all(10),
                    child: Column(
                        children: [
                          Text("Stars featured in this film:"),
                          Text('Emily Blunt'),
                          Text('Josh Brolin'),
                          Text('Benicio Del Toro'),
                        ]
                    )
                ),
                Container(
                    margin: EdgeInsets.all(10),
                    child: Column(
                        children: [
                          Text('Runtime: 2 hours, 1 minute'),
                          Text('Rated 7 out of 10 stars')
                        ]
                    )
                ),
                Container(
                    height: 100,
                    width: 300,
                    margin: EdgeInsets.all(10),
                    child: Text('Jason Bailey of Flavorwire says "It\'s a thoughtful film\, but also a visceral and affecting one\, capturing the intensity of these raids and encounters."')
                ),
                Container(
                    height: 100,
                    width: 300,
                    margin: EdgeInsets.all(10),
                    child: Text('Adam Nayman of Reverse Shot said in his review "Sicario is as brilliantly made as Prisoners, perhaps even more so."')
                ),
              ]
          )
      ),
    );
  }
}
