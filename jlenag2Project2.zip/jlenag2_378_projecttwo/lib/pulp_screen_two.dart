import 'package:flutter/material.dart';
//Coded by Joseph Lenaghan, Project Two for CS 378 at UIC | UIN :676805596 | 11/5/22



class PulpScreenTwo extends StatelessWidget {
  const PulpScreenTwo ({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        elevation: 15,
        toolbarHeight: 90,
        backgroundColor: Colors.blueGrey,
        shadowColor: Colors.black,
        shape:  RoundedRectangleBorder(
          borderRadius: BorderRadius.horizontal(
              left: Radius.circular(10),
              right: Radius.circular(10)
          ),
        ),
        flexibleSpace: FlexibleSpaceBar(
            title: Text(
              'A Night at the Movies',
              style: TextStyle(
                color: Colors.white,
                shadows: <Shadow>[
                  Shadow(
                    offset: Offset(1,1),
                    color: Colors.black,
                  )
                ],
              ),
            ),
            background: Image.asset('images/popcorn.jpg')
        ),
      ),
      body: Center(

          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                    height: 30,
                    width: 230,
                    margin: EdgeInsets.all(10),
                    child: Text('This film was directed by Quentin Tarantino')
                ),
                Container(
                    margin: EdgeInsets.all(10),
                    child: Column(
                        children: [
                          Text("Stars featured in this film:"),
                          Text('John Travolta'),
                          Text('Uma Thurman'),
                          Text('Samuel L. Jackson'),
                          Text('Bruce Willis')
                        ]
                    )
                ),
                Container(
                    margin: EdgeInsets.all(10),
                    child: Column(
                        children: [
                          Text('Runtime: 2 hours, 34 minutes'),
                          Text('Rated 8 out of 10 stars')
                        ]
                    )
                ),
                Container(
                    height: 100,
                    width: 300,
                    margin: EdgeInsets.all(10),
                    child: Text('Adam Nayman of The Ringer describes it as "Quentin Tarantino\'s retro-fetishism was the future of American cinema."')
                ),
                Container(
                    height: 100,
                    width: 300,
                    margin: EdgeInsets.all(10),
                    child: Text('Jay Carr of the Boston Globe says "It\'s hot\, it\'s cool and -- for a movie that sometimes comes at you like a blindsiding fist -- it\'s unfailingly playful."')
                ),
              ]
          )
      ),
    );
  }
}
