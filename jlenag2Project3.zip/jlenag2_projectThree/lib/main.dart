import 'package:flutter/material.dart';
// coded by Joseph Lenaghan for CS 378 Fall 2022 | UIN : 676805596 | 11/18/22
// uses some code provided by professor Hallenbeck in class
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Animation Nation'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {




  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      backgroundColor: Colors.indigo,
      appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(
          'Animation Nation',
          style: TextStyle(
            fontSize: 30,
            shadows: <Shadow>[
          Shadow(
          offset: Offset(2.0, 2.0),
          blurRadius: 3.0,
          color: Colors.black
        ),
          ]
        ),
        ),
        centerTitle: true,
        toolbarHeight: 75, // adjusting visual aspects of the appbar
        backgroundColor: Colors.indigoAccent,

      ),
      body: ListView( // this listview will contain each of the eight buttons for each animation
        padding: EdgeInsets.all(15),
        children: <Widget>[

          OutlinedButton( // first button that redirects to the first explicit animation
            child: const Text(
              'Explicit Animation One',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  shadows: <Shadow>[
                    Shadow(
                        offset: Offset(2.0, 2.0),
                        blurRadius: 3.0,
                        color: Colors.black
                    ),
                  ]
              ),
            ),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.purple),
              shadowColor: MaterialStateProperty.all<Color>(Colors.black),
              elevation: MaterialStateProperty.all(5),
            ),
            onPressed: () {
              Navigator.of(context).push(PageRouteBuilder(
                  pageBuilder: (context, animation, anotherAnimation) {
                    return ExplicitOne(); // on button push redirect to the first explicit animation
                  },
                  barrierColor: Colors.purple,
                  transitionDuration: Duration(milliseconds: 2000),
                  transitionsBuilder:
                      (context, animation, anotherAnimation, child) {
                    animation =
                        CurvedAnimation(curve: Curves.decelerate, parent: animation);
                    return SlideTransition( // making use of slide transition
                      position:
                      Tween(begin: Offset(0.0, 1.0), end: Offset(0.0, 0.0))
                          .animate(animation),
                      child: child,
                    );
                  }));
            },
          ),// end of the first button that redirects to the explicit
          OutlinedButton( // second button that redirects to the second explicit animation
            child: const Text(
              'Explicit Animation Two',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  shadows: <Shadow>[
                    Shadow(
                        offset: Offset(2.0, 2.0),
                        blurRadius: 3.0,
                        color: Colors.black
                    ),
                  ]
              ),
            ),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.green),
              shadowColor: MaterialStateProperty.all<Color>(Colors.black),
              elevation: MaterialStateProperty.all(5),
            ),
            onPressed: () {
              Navigator.of(context).push(PageRouteBuilder(
                  pageBuilder: (context, animation, anotherAnimation) {
                    return ExplicitTwo(); // on button press, redirect to the second explicit animation
                  },
                  barrierColor: Colors.green,
                  transitionDuration: Duration(milliseconds: 2000),
                  transitionsBuilder:
                      (context, animation, anotherAnimation, child) {
                    animation =
                        CurvedAnimation(curve: Curves.bounceIn, parent: animation);
                    return SlideTransition( // making use of another slide transition but this time with a different curve
                      position:
                      Tween(begin: Offset(0.0, 1.0), end: Offset(0.0, 0.0))
                          .animate(animation),
                      child: child,
                    );
                  }));
            },
          ), // end of the second button that redirects to the second explicit animation
          OutlinedButton( // third button that redirects to the third required explicit animation
            child: const Text(
              'Explicit Animation Three',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  shadows: <Shadow>[
                    Shadow(
                        offset: Offset(2.0, 2.0),
                        blurRadius: 3.0,
                        color: Colors.black
                    ),
                  ]
              ),
            ),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.red),
              shadowColor: MaterialStateProperty.all<Color>(Colors.black),
              elevation: MaterialStateProperty.all(5),
            ),
            onPressed: () {
              Navigator.of(context).push(PageRouteBuilder(
                  pageBuilder: (context, animation, anotherAnimation) {
                    return ExplicitThree(); // when button is pressed redirect to the third required explicit animation
                  },
                  barrierColor: Colors.red,
                  transitionDuration: Duration(milliseconds: 2000),
                  transitionsBuilder:
                      (context, animation, anotherAnimation, child) {
                    animation =
                        CurvedAnimation(curve: Curves.slowMiddle, parent: animation);
                    return RotationTransition(turns: animation, child: child,); // another rotation transition that uses a different curve
                  }));
            },
          ), // end of button that redirects to third explicit animation
          OutlinedButton( // fourth button that redirects to the first required implicit animation
            child: const Text(
              'Implict Animation One',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  shadows: <Shadow>[
                    Shadow(
                        offset: Offset(2.0, 2.0),
                        blurRadius: 3.0,
                        color: Colors.black
                    ),
                  ]
              ),
            ),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.yellow),
              shadowColor: MaterialStateProperty.all<Color>(Colors.black),
              elevation: MaterialStateProperty.all(5),
            ),
            onPressed: () {
              Navigator.of(context).push(PageRouteBuilder(
                  pageBuilder: (context, animation, anotherAnimation) {
                    return ImplicitOne(); // on button press transition to the first implicit animation
                  },
                  barrierColor: Colors.yellow,
                  transitionDuration: Duration(milliseconds: 4000),
                  transitionsBuilder:
                      (context, animation, anotherAnimation, child) {
                    animation =
                        CurvedAnimation(curve: Curves.easeOutBack, parent: animation);
                    return FadeTransition(opacity: animation, child: child,); // fade transition takes us to the animation
                  }));
            },
          ), // end of the button that redirects to the first implicit animation
          OutlinedButton( // second button that redirects to the second implicit animation
            child: const Text(
              'Implicit Animation Two',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  shadows: <Shadow>[
                    Shadow(
                        offset: Offset(2.0, 2.0),
                        blurRadius: 3.0,
                        color: Colors.black
                    ),
                  ]
              ),
            ),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.orange),
              shadowColor: MaterialStateProperty.all<Color>(Colors.black),
              elevation: MaterialStateProperty.all(5),
            ),
            onPressed: () {
              Navigator.of(context).push(PageRouteBuilder(
                  pageBuilder: (context, animation, anotherAnimation) {
                    return ImplicitTwo(); // when button is presed redirect to the second implicit animation
                  },
                  barrierColor: Colors.orange,
                  transitionDuration: Duration(milliseconds: 3000),
                  transitionsBuilder:
                      (context, animation, anotherAnimation, child) {
                    animation =
                        CurvedAnimation(curve: Curves.bounceInOut, parent: animation);
                    return RotationTransition(turns: animation, child: child,); //return a rotation transition with a different curve applied
                  }));
            },
          ), // end of button that redirects to the second implicit animation
          OutlinedButton( // third button that redirects to third and final required implicit animation
            child: const Text(
              'Implicit Animation Three',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  shadows: <Shadow>[
                    Shadow(
                        offset: Offset(2.0, 2.0),
                        blurRadius: 3.0,
                        color: Colors.black
                    ),
                  ]
              ),
            ),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.pink),
              shadowColor: MaterialStateProperty.all<Color>(Colors.black),
              elevation: MaterialStateProperty.all(5),
            ),
            onPressed: () {
              Navigator.of(context).push(PageRouteBuilder(
                  pageBuilder: (context, animation, anotherAnimation) {
                    return ImplicitThree(); // when button is pressed redirect to the third implicit animation
                  },
                  barrierColor: Colors.pink,
                  transitionDuration: Duration(milliseconds: 2000),
                  transitionsBuilder:
                      (context, animation, anotherAnimation, child) {
                    animation =
                        CurvedAnimation(curve: Curves.easeOutExpo , parent: animation);
                    return SlideTransition( // another slide transition with a different curve effect applied
                      position:
                      Tween(begin: Offset(0.0, 1.0), end: Offset(0.0, 0.0))
                          .animate(animation),
                      child: child,
                    );
                  }));
            },
          ), // end of button that redirects to the third and final implicit animation
          OutlinedButton( // button that redirects to an animation that is implicit
            child: const Text(
              'Bonus Animation One',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  shadows: <Shadow>[
                    Shadow(
                        offset: Offset(2.0, 2.0),
                        blurRadius: 3.0,
                        color: Colors.black
                    ),
                  ]
              ),
            ),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.cyan),
              shadowColor: MaterialStateProperty.all<Color>(Colors.black),
              elevation: MaterialStateProperty.all(5),
            ),
            onPressed: () {
              Navigator.of(context).push(PageRouteBuilder(
                  pageBuilder: (context, animation, anotherAnimation) {
                    return BonusOne(); // on button press redirect to the implicit animation
                  },
                  barrierColor: Colors.cyan,
                  transitionDuration: Duration(milliseconds: 2000),
                  transitionsBuilder:
                      (context, animation, anotherAnimation, child) {
                    animation =
                        CurvedAnimation(curve: Curves.easeInQuint , parent: animation);
                    return SlideTransition( // slide transition with a different curve from others
                      position:
                      Tween(begin: Offset(0.0, 1.0), end: Offset(0.0, 0.0))
                          .animate(animation),
                      child: child,
                    );
                  }));
            },
          ),
          OutlinedButton(
            child: const Text(
              'Bonus Animation Two',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  shadows: <Shadow>[
                    Shadow(
                        offset: Offset(2.0, 2.0),
                        blurRadius: 3.0,
                        color: Colors.black
                    ),
                  ]
              ),
            ),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.amber),
              shadowColor: MaterialStateProperty.all<Color>(Colors.black),
              elevation: MaterialStateProperty.all(5),
            ),
            /*  onPressed: (){Navigator.push(context,
              MaterialPageRoute(builder: (context) => const RouteTwo()),);},*/
            onPressed: () {
              Navigator.of(context).push(PageRouteBuilder(
                  pageBuilder: (context, animation, anotherAnimation) {
                    return BonusTwo();
                  },
                  barrierColor: Colors.amber,
                  transitionDuration: Duration(milliseconds: 2000),
                  transitionsBuilder:
                      (context, animation, anotherAnimation, child) {
                    animation =
                        CurvedAnimation(curve: Curves.easeInSine , parent: animation);
                    return RotationTransition(turns: animation, child: child,);
                  }));
            },
          )

        ],
      ),
    );
  }
}


//--------------------------------------------------------- //
// CODE CONCERNING REQUIRED EXPLICIT ANIMATIONS FOUND BELOW //
//-------------------------------------------------------- //

/// class for explicit animation one, involves modified code provided by Professor Hallenbeck
class ExplicitOne extends StatefulWidget {
  const ExplicitOne({Key? key}) : super(key: key);

  @override
  State<ExplicitOne> createState() => _ExplicitOneState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _ExplicitOneState
    extends State<ExplicitOne>
    with TickerProviderStateMixin {
  late final AnimationController _controller = AnimationController( // create the animation controller
    duration: const Duration(seconds: 8),
    reverseDuration: const Duration(seconds: 8),
    vsync: this,
  )..repeat(reverse: false);
  late final Animation<double> _animation = CurvedAnimation( // create the animation to be performed
    parent: _controller,
    curve: Curves.bounceInOut,
    reverseCurve: Curves.bounceOut
  );

  @override
  void dispose() {
    // Don't forget to deallocate AnimationController
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'Explicit Animation One',
          style: TextStyle(
              fontSize: 30,
              shadows: <Shadow>[
                Shadow(
                    offset: Offset(2.0, 2.0),
                    blurRadius: 3.0,
                    color: Colors.black
                ),
              ]
          ),
        ),
        centerTitle: true,
        toolbarHeight: 75,
        backgroundColor: Colors.purple,
      ),
      body: Row(
        // RotationTransition is an explicit animation
        children: <Widget>[
          Flexible( // first flexible space covers 1/3rd of the screen and gives details about the animation
            flex : 1,
            child: Container(
                padding: EdgeInsets.fromLTRB(20, 0, 0, 100),
                child: Text(
                "Spinning judo throw! He's going to feel that in the morning!",
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      shadows: <Shadow>[
                        Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 3.0,
                            color: Colors.grey
                        ),
                      ]
                  ),

            ),
            ),
          ),
          Flexible( // second flexible space covers 2/3rds of the screen and contains the animation itself as well as the buttons used to control it
            flex: 2,
            child: RotationTransition(
              turns: _animation,
              child: const Padding(
                padding: EdgeInsets.fromLTRB(75, 50, 75, 50),
                child: Image(
                  image : AssetImage("images/flip.jpg")
                )

              ),
            ),
          ),
          Column( // this column contains the two buttons that are used for controlling the explicit animation
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              OutlinedButton( // this button is responsible for starting and stopping the animation
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.indigoAccent),
                  shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                  elevation: MaterialStateProperty.all(5),
                ),
                child : Text(
                    'stop/start the animation',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      shadows: <Shadow>[
                        Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 3.0,
                            color: Colors.black
                        ),
                      ]
                  ),
                ),
                onPressed: () {
                  if(_controller.isAnimating == true) {
                    _controller.stop();
                  }
                  else{
                    if(_controller.status == AnimationStatus.reverse){
                      _controller.reverse();
                    }
                    else{
                      _controller.repeat();
                    }
                  }
                },
              ),
              OutlinedButton( // this button is responsible for reversing the direction of the animation
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.indigoAccent),
                  shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                  elevation: MaterialStateProperty.all(5),
                ),
                child : Text(
                  'change animation direction',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      shadows: <Shadow>[
                        Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 3.0,
                            color: Colors.black
                        ),
                      ]
                  ),
                ),
                onPressed: () {
                  if(_controller.status == AnimationStatus.dismissed || _controller.status == AnimationStatus.reverse){
                    _controller.repeat();
                  }
                  else {
                    _controller.reverse();
                  }
                },
              ),
              Container( // providing some text so the user is aware that once the image finishes its reverse animation it will stop
                  width: 175,
                  child : Text(
                      "reversing the animation completes it,if you want the animation to start again, press the first or second button once the reverse animation completes! The button above also works for pausing the reverse animation!",
                      style: TextStyle(
                          fontSize: 8
                      )
                  )
              )
            ]
          )
        ]
      ),
    );
  }
}

/// class for explicit animation two, involves modified code provided by Professor Hallenbeck
class ExplicitTwo extends StatefulWidget {
  const ExplicitTwo({Key? key}) : super(key: key);

  @override
  State<ExplicitTwo> createState() => _ExplicitTwoState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _ExplicitTwoState
    extends State<ExplicitTwo>
    with TickerProviderStateMixin {
  late final AnimationController _controller = AnimationController( // create the animation controller
    duration: const Duration(seconds: 4),
    reverseDuration: const Duration(seconds: 4),
    vsync: this,
  )..repeat(reverse: false);
  late final Animation<double> _animation = CurvedAnimation( // create the animation to be performed
      parent: _controller,
      curve: Curves.easeInOut,
      reverseCurve: Curves.easeOut
  );

  @override
  void dispose() {
    // Don't forget to deallocate AnimationController
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'Explicit Animation Two',
          style: TextStyle(
              fontSize: 30,
              shadows: <Shadow>[
                Shadow(
                    offset: Offset(2.0, 2.0),
                    blurRadius: 3.0,
                    color: Colors.black
                ),
              ]
          ),
        ),
        centerTitle: true,
        toolbarHeight: 75,
        backgroundColor: Colors.green,
      ),
      body: Row(
        // RotationTransition is an explicit animation
          children: <Widget>[
            Flexible( // first flexible space covers 1/3rd of the screen and gives details about the animation
              flex : 1,
              child: Container(
                padding: EdgeInsets.fromLTRB(20, 0, 0, 100),
                child: Text(
                  "BOO! did I scare you? Okay, probably not with such a friendly ghost ;)",
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      shadows: <Shadow>[
                        Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 3.0,
                            color: Colors.grey
                        ),
                      ]
                  ),

                ),
              ),
            ),
            Flexible( // second flexible space covers 2/3rds of the screen and contains the animation itself as well as the buttons used to control it
              flex: 2,
              child: FadeTransition(
                opacity: _animation,
                child: const Padding(
                    padding: EdgeInsets.fromLTRB(75, 50, 75, 50),
                    child: Image(
                        image : AssetImage("images/boo!.png") // providing an image for the animation to be performed on
                    )

                ),
              ),
            ),
            Column( // this column contains the two buttons that are used for controlling the explicit animation
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  OutlinedButton( // this button is responsible for starting and stopping the animation
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.indigoAccent),
                      shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                      elevation: MaterialStateProperty.all(5),
                    ),
                    child : Text(
                      'stop/start the animation',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          shadows: <Shadow>[
                            Shadow(
                                offset: Offset(2.0, 2.0),
                                blurRadius: 3.0,
                                color: Colors.black
                            ),
                          ]
                      ),
                    ),
                    onPressed: () {
                      if(_controller.isAnimating == true) {
                        _controller.stop();
                      }
                      else{
                        if(_controller.status == AnimationStatus.reverse){
                          _controller.reverse();
                        }
                        else{
                          _controller.repeat();
                        }
                      }
                    },
                  ),
                  OutlinedButton( // this button is responsible for reversing the direction of the animation
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.indigoAccent),
                      shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                      elevation: MaterialStateProperty.all(5),
                    ),
                    child : Text(
                      'change animation direction',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          shadows: <Shadow>[
                            Shadow(
                                offset: Offset(2.0, 2.0),
                                blurRadius: 3.0,
                                color: Colors.black
                            ),
                          ]
                      ),
                    ),
                    onPressed: () {
                      if(_controller.status == AnimationStatus.dismissed || _controller.status == AnimationStatus.reverse){
                        _controller.repeat();
                      }
                      else {
                        _controller.reverse();
                      }
                    },
                  ),
                  Container( // providing some text so the user is aware that once the image finishes its reverse animation it will stop
                      width: 175,
                      child : Text(
                          "reversing the animation completes it,if you want the animation to start again, press the first or second button once the reverse animation completes! The button above also works for pausing the reverse animation!",
                          style: TextStyle(
                              fontSize: 8
                          )
                      )
                  )
                ]
            )
          ]
      ),
    );
  }
}


/// class for explicit animation three, involves modified code provided by Professor Hallenbeck
class ExplicitThree extends StatefulWidget {
  const ExplicitThree({Key? key}) : super(key: key);

  @override
  State<ExplicitThree> createState() => _ExplicitThreeState();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _ExplicitThreeState
    extends State<ExplicitThree>
    with TickerProviderStateMixin {
  late final AnimationController _controller = AnimationController( // create the animation controller
    duration: const Duration(seconds: 8),
    reverseDuration: const Duration(seconds: 8),
    vsync: this,
  )..repeat(reverse: false);
  late final Animation<double> _animation = CurvedAnimation( // create the animation to be performed
      parent: _controller,
      curve: Curves.easeInOut,
      reverseCurve: Curves.easeOut
  );

  @override
  void dispose() {
    // Don't forget to deallocate AnimationController
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'Explicit Animation Three',
          style: TextStyle(
              fontSize: 30,
              shadows: <Shadow>[
                Shadow(
                    offset: Offset(2.0, 2.0),
                    blurRadius: 3.0,
                    color: Colors.black
                ),
              ]
          ),
        ),
        centerTitle: true,
        toolbarHeight: 75,
        backgroundColor: Colors.red,
      ),
      body: Row(
        // RotationTransition is an explicit animation
          children: <Widget>[
            Flexible( // first flexible space covers 1/3rd of the screen and gives details about the animation
              flex : 1,
              child: Container(
                padding: EdgeInsets.fromLTRB(20, 0, 0, 100),
                child: Text(
                  "Donkey Kong stops by to give a thumbs up!",
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      shadows: <Shadow>[
                        Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 3.0,
                            color: Colors.grey
                        ),
                      ]
                  ),

                ),
              ),
            ),
            Flexible( // second flexible space covers 2/3rds of the screen and contains the animation itself as well as the buttons used to control it
              flex: 2,
              child: ScaleTransition(
                scale: _animation,
                child: const Padding(
                    padding: EdgeInsets.fromLTRB(75, 50, 75, 50),
                    child: Image(
                        image : AssetImage("images/kong.jpg") // providing an image for the animation to be used on
                    )

                ),
              ),
            ),
            Column( // this column contains the two buttons used for controlling the explicit animation
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  OutlinedButton( // this button is used to stop and start the animation
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.indigoAccent),
                      shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                      elevation: MaterialStateProperty.all(5),
                    ),
                    child : Text(
                      'stop/start the animation',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          shadows: <Shadow>[
                            Shadow(
                                offset: Offset(2.0, 2.0),
                                blurRadius: 3.0,
                                color: Colors.black
                            ),
                          ]
                      ),
                    ),
                    onPressed: () {
                      if(_controller.isAnimating == true) {
                        _controller.stop();
                      }
                      else{
                        if(_controller.status == AnimationStatus.reverse){
                          _controller.reverse();
                        }
                        else{
                          _controller.repeat();
                        }
                      }
                    },
                  ),
                  OutlinedButton( // this button is used to reverse the direction of the animation, either forward or backward
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.indigoAccent),
                      shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                      elevation: MaterialStateProperty.all(5),
                    ),
                    child : Text(
                      'change animation direction',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          shadows: <Shadow>[
                            Shadow(
                                offset: Offset(2.0, 2.0),
                                blurRadius: 3.0,
                                color: Colors.black
                            ),
                          ]
                      ),
                    ),
                    onPressed: () {
                      if(_controller.status == AnimationStatus.dismissed || _controller.status == AnimationStatus.reverse){
                        _controller.repeat();
                      }
                      else {
                        _controller.reverse();
                      }
                    },
                  ),
                  Container( // providing some text so the user is aware that once the image finishes its reverse animation it will stop
                    width: 175,
                    child : Text(
                        "reversing the animation completes it,if you want the animation to start again, press the first or second button once the reverse animation completes! The button above also works for pausing the reverse animation!",
                        style: TextStyle(
                            fontSize: 8
                        )
                    )
                  )
                ]
            )
          ]
      ),
    );
  }
}
//-------------------------------------------------------- //
// END OF ALL CODE CONCERNING REQUIRED EXPLICIT ANIMATIONS //
//-------------------------------------------------------- //


//-------------------------------------------------------- //
// CODE CONCERNING REQUIRED IMPLICIT ANIMATIONS FOUND BELOW //
//-------------------------------------------------------- //

/// implicit animation one using modified code provided by professor Hallenbeck to avoid producing the same animation, the bowling ball spins in the opposite direction and at a different rate with a curve applied
class ImplicitOne extends StatefulWidget {
  const ImplicitOne({Key? key}) : super(key: key);



  @override
  BallState createState() => BallState();
}

class BallState extends State<ImplicitOne> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Implicit Animation One',
          style: TextStyle(
              fontSize: 30,
              shadows: <Shadow>[
                Shadow(
                    offset: Offset(2.0, 2.0),
                    blurRadius: 3.0,
                    color: Colors.black
                ),
              ]
          ),
        ),
        centerTitle: true,
        toolbarHeight: 75,
        backgroundColor: Colors.yellow,
      ),

      backgroundColor: Colors.white,

      body: Row(
        children: <Widget>[
          Flexible( // flexible space covers a 1/3rd of the screen and describes the animation
            flex : 1,
            child: Container(
              padding: EdgeInsets.fromLTRB(20, 0, 50, 100),
              child: Text(
                "A bowling ball headed for a strike!",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                    shadows: <Shadow>[
                      Shadow(
                          offset: Offset(2.0, 2.0),
                          blurRadius: 3.0,
                          color: Colors.grey
                      ),
                    ]
                ),
              ),
            ),
          ),
          Flexible( // flexible space covers 2/3rds of the screen and contains the animation
            flex: 2,
            child:Container(
              padding: EdgeInsets.fromLTRB(100,10,0,0),
              child: TweenAnimationBuilder(
                duration: const Duration(seconds: 10),
                curve: Curves.easeInSine,
                tween: Tween<double>(begin: 2 * 50 , end: 0),
                builder: (_, double angle, __) {
              // Animation value should be same type as Tween typ
                return Transform.rotate( // performing a rotate transformation on the provided image
                  angle: angle,
                  child: Image(
                     image: AssetImage("images/ball.jpg"),
                     width: 250,
                     height: 250,
                  ),
                      );
                }),
             )
          ),
            ],
      ),
    );
  }
}

/// implicit animation Two using modified code provided by professor Hallenbeck
class ImplicitTwo extends StatefulWidget {
  const ImplicitTwo({Key? key}) : super(key: key);



  @override
  TreeState createState() => TreeState();
}

class TreeState extends State<ImplicitTwo> {
  bool isGrown = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Implicit Animation Two',
          style: TextStyle(
              fontSize: 30,
              shadows: <Shadow>[
                Shadow(
                    offset: Offset(2.0, 2.0),
                    blurRadius: 3.0,
                    color: Colors.black
                ),
              ]
          ),
        ),
        centerTitle: true,
        toolbarHeight: 75,
        backgroundColor: Colors.orange,
      ),

      backgroundColor: Colors.white,

      body: Row(
        children: <Widget>[
          Flexible( // flexible space covers 1/3 of the screen and describes the animation
            flex : 1,
            child: Container(
              child: Text(
                "Press the button and watch the tree grow!",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                    shadows: <Shadow>[
                      Shadow(
                          offset: Offset(2.0, 2.0),
                          blurRadius: 3.0,
                          color: Colors.grey
                      ),
                    ]
                ),
              ),
            ),
          ),
          Flexible( // flexible space covers most of the scren and contains the animation as well as a button to start it
              flex: 3,
              child:
              Row(children: <Widget>[

                AnimatedContainer( // animated container that will perform an animation the provided image
                  duration: const Duration(seconds: 06),
                  curve: Curves.easeOut,
                  child: Image.asset("images/tree.png"),
                    width: isGrown? 300 : 20, // based on the state of isGrown? "Grow" the tree by increasing it's height and width
                    height: isGrown? 500: 20,
                    ),
              OutlinedButton( // button that kicks off the animation
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.brown),
                  shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                  elevation: MaterialStateProperty.all(5),
                ),
                child: Text(
                  'Press me to grow the Tree!',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      shadows: <Shadow>[
                        Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 3.0,
                            color: Colors.black
                        ),
                      ]
                  ),
                ),
                onPressed:() => setState((){isGrown = true;}),
              )
              ]),
          ),
        ],
      ),

    );
  }
}


/// implicit animation Three using modified code provided by professor Hallenbeck
class ImplicitThree extends StatefulWidget {
  const ImplicitThree({Key? key}) : super(key: key);



  @override
  TurtleState createState() => TurtleState();
}

class TurtleState extends State<ImplicitThree> {
  bool isMoved = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Implicit Animation Three',
          style: TextStyle(
              fontSize: 30,
              shadows: <Shadow>[
                Shadow(
                    offset: Offset(2.0, 2.0),
                    blurRadius: 3.0,
                    color: Colors.black
                ),
              ]
          ),
        ),
        centerTitle: true,
        toolbarHeight: 75,
        backgroundColor: Colors.pink,
      ),

      backgroundColor: Colors.white,

      body: Row(
        children: <Widget>[
          Flexible( // flexible space contains info about the animation as well as a button to make the animation work
            flex : 1,
            child:Column(children: <Widget>[
              Container(
              child: Text(
                "Press the button and watch the turtle go!",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                    shadows: <Shadow>[
                      Shadow(
                          offset: Offset(2.0, 2.0),
                          blurRadius: 3.0,
                          color: Colors.grey
                      ),
                    ]
                ),
              ),
            ),
              OutlinedButton( // outlined button the user presses to make the animation work

                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.brown),
                  shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                  elevation: MaterialStateProperty.all(5),
                ),
                child: Text(
                  'Move the turtle!',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      shadows: <Shadow>[
                        Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 3.0,
                            color: Colors.black
                        ),
                      ]
                  ),
                ),
                onPressed:() => setState((){isMoved = !isMoved;}),
              )
            ]),
          ),
          Flexible( // flexible space contains the animation
            flex: 3,
            child:
            Row(children: <Widget>[

              AnimatedContainer( // animated container that performs an animation on the provided image
                duration: const Duration(seconds: 03),
                margin: isMoved? EdgeInsets.fromLTRB(300, 0,0, 0) : EdgeInsets.fromLTRB(0, 0, 0, 0), // based on the state of isMoved will determine where the turtles location on the screen
                curve: Curves.easeInSine,
                child: Image.asset("images/turdle.png"),
                width: 200,
                height: 200,

              ),
            ]),
          ),
        ],
      ),

    );
  }
}

//-------------------------------------------------------- //
// END OF ALL CODE CONCERNING REQUIRED IMPLICIT ANIMATIONS //
//-------------------------------------------------------- //


//-------------------------------------------------------- //
// CODE CONCERNING REQUIRED BONUS ANIMATIONS FOUND BELOW   //
//-------------------------------------------------------- //


/// bonus implicit animation using modified code provided by professor Hallenbeck
class BonusOne extends StatefulWidget {
  const BonusOne({Key? key}) : super(key: key);



  @override
  GoblinState createState() => GoblinState();
}

class GoblinState extends State<BonusOne> {
  bool isJumping = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Bonus Animation One',
          style: TextStyle(
              fontSize: 30,
              shadows: <Shadow>[
                Shadow(
                    offset: Offset(2.0, 2.0),
                    blurRadius: 3.0,
                    color: Colors.black
                ),
              ]
          ),
        ),
        centerTitle: true,
        toolbarHeight: 75,
        backgroundColor: Colors.cyan,
      ),

      backgroundColor: Colors.white,

      body: Row(
        children: <Widget>[
          Flexible( // flexible space contains a description about the animation
            flex : 1,
            child: Container(
              child: Text(
                "press the button to make the goblin jump up and down!",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                    shadows: <Shadow>[
                      Shadow(
                          offset: Offset(2.0, 2.0),
                          blurRadius: 3.0,
                          color: Colors.grey
                      ),
                    ]
                ),

              ),
            ),
          ),
          Flexible( // flexible space containing the animation as well as button to make it work
            flex: 3,
            child:
            Row(children: <Widget>[

              AnimatedContainer( // animated container used to perform an animation on the provided image
                duration: const Duration(seconds: 03),
                curve: Curves.easeOut,
                child: Image(
                 image : AssetImage("images/goblin.jpg"),
                  width: 250,
                  height: 250,
                ),
                margin: isJumping? EdgeInsets.fromLTRB(0, 0, 0,200) : EdgeInsets.fromLTRB(0,100,0,0) // based on the state of isJumping, will determine the location of the image in terms of the screen
              ),
              OutlinedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.brown),
                  shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                  elevation: MaterialStateProperty.all(5),
                ),
                child: Text(
                  'Jump for the sky/come back down!',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      shadows: <Shadow>[
                        Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 3.0,
                            color: Colors.black
                        ),
                      ]
                  ),

                ),
                onPressed:() => setState((){isJumping = !isJumping;}), // controls the state of the animation on button press
              )
            ]),
          ),
        ],
      ),

    );
  }
}


/// bonus explicit animation that involves modified code provided by Professor Hallenbeck
class BonusTwo extends StatefulWidget {
  const BonusTwo({Key? key}) : super(key: key);

  @override
  State<BonusTwo> createState() => _BonusTwo();
}

/// This is the private State class that goes with MyStatefulWidget.
/// AnimationControllers can be created with `vsync: this` because of TickerProviderStateMixin.
class _BonusTwo
    extends State<BonusTwo>
    with TickerProviderStateMixin {
  late final AnimationController _controller = AnimationController( // create the animation controller
    duration: const Duration(seconds: 2),
    reverseDuration: const Duration(seconds: 2),
    vsync: this,
  )..repeat(reverse: true);
  late final Animation<double> _animation = CurvedAnimation( // create the animation
      parent: _controller,
      curve: Curves.decelerate,
      reverseCurve: Curves.linearToEaseOut
  );

  @override
  void dispose() {
    // Don't forget to deallocate AnimationController
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'Bonus Animation Two',
          style: TextStyle(
              fontSize: 30,
              shadows: <Shadow>[
                Shadow(
                    offset: Offset(2.0, 2.0),
                    blurRadius: 3.0,
                    color: Colors.black
                ),
              ]
          ),
        ),
        centerTitle: true,
        toolbarHeight: 75,
        backgroundColor: Colors.amber,
      ),
      body: Row(
        // RotationTransition is an explicit animation
          children: <Widget>[
            Flexible( // this flexible space covers 1/3rd of the screen and describes the animation
              flex : 1,
              child: Container(
                padding: EdgeInsets.fromLTRB(20, 0, 0, 100),
                child: Text(
                  "An alien from a far away planet uses their teleporter to say hello!",
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      shadows: <Shadow>[
                        Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 3.0,
                            color: Colors.grey
                        ),
                      ]
                  ),

                ),
              ),
            ),
            Flexible( // this flexible space accounts for 2/3rds of the screen and contains the animation as well buttons to control it
              flex: 2,
              child: SizeTransition(
                sizeFactor: _animation,
                child: const Padding(
                    padding: EdgeInsets.fromLTRB(75, 50, 75, 50),
                    child: Image(
                        image : AssetImage("images/alien.png")
                    )

                ),
              ),
            ),
            Column( // this column contains the buttons responsible for controlling the explicit animation
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  OutlinedButton( // this button is responsible for starting and stopping the animation
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.indigoAccent),
                      shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                      elevation: MaterialStateProperty.all(5),
                    ),
                    child : Text(
                      'stop/start the animation',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          shadows: <Shadow>[
                            Shadow(
                                offset: Offset(2.0, 2.0),
                                blurRadius: 3.0,
                                color: Colors.black
                            ),
                          ]
                      ),
                    ),
                    onPressed: () {
                      if(_controller.isAnimating == true) {
                        _controller.stop();
                      }
                      else{
                        if(_controller.status == AnimationStatus.reverse){
                          _controller.reverse();
                        }
                        else{
                          _controller.repeat();
                        }
                      }
                    },
                  ),
                  OutlinedButton( // this button is responsible for reversing the direction of the animation
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.indigoAccent),
                      shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                      elevation: MaterialStateProperty.all(5),
                    ),
                    child : Text(
                      'change animation direction',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          shadows: <Shadow>[
                            Shadow(
                                offset: Offset(2.0, 2.0),
                                blurRadius: 3.0,
                                color: Colors.black
                            ),
                          ]
                      ),
                    ),
                    onPressed: () {
                      if(_controller.status == AnimationStatus.dismissed || _controller.status == AnimationStatus.reverse){
                        _controller.repeat();
                      }
                      else {
                        _controller.reverse();
                      }
                    },
                  ),
                  Container( // providing some text so the user is aware that once the image finishes its reverse animation it will stop
                      width: 175,
                      child : Text(
                          "reversing the animation completes it,if you want the animation to start again, press the first or second button once the reverse animation completes! The button above also works for pausing the reverse animation!",
                          style: TextStyle(
                              fontSize: 8
                          )
                      )
                  )
                ]
            )
          ]
      ),
    );
  }
}


//-------------------------------------------------------- //
// END OF ALL CODE CONCERNING REQUIRED BONUS ANIMATIONS    //
//-------------------------------------------------------- //