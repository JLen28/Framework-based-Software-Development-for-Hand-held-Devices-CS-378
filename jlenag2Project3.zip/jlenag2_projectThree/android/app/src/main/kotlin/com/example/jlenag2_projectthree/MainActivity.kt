package com.example.jlenag2_projectthree

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
