package com.example.jlenag2_projectfour_378

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
