import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:audioplayers/audioplayers.dart';

// coded by Joseph Lenaghan for CS 378 Project Four
// || Fall 2022 || UIN:676805596 || 11/27/22
//
//The first package I used is fluttertoast, which allows for Toast message functionality similar to that seen
// when coding android applications using Java. I am taking CS 478 this semester and I find toast messages to
// be an elegant and handy way of showing a user relevant information, this package includes that functionality with
// the added benefit of the easy implementation that is abundant in Flutter. Toast messages can be created
// on the fly in the listener's that need them, makes for a very handy and elegant way of informing the user
// of information pertaining to their selections. By default, fluttertoast messages are displayed at the bottom
// of the screen and can be customized for different background colors, fontsizes, contained text, and length of
// display.
//
//The second package I used is audioplayers, which allows the ability for audio assets to be played in the
// application. I recently coded a project for CS 478 that involved the use of audio files and a service being used
// to play them. It was a very difficult project and I wanted to see how this process compared in Flutter. Both
// languages make it very easy for adding audio assets and playing them in application. Flutter makes uses of an
// AudioPlayer class that takes a Source parameter that can be an asset provided in the 'assets' folder. Multiple file
// types are supported which makes for some neat functionality. The AudioPlayer can be readily paused, resumed, and stopped
// and supports listener functionality on song completion or state changes. This provides the opportunity to  make an application
// much more entertaining/interesting when there is audio played on user interaction. Through a button press, gesture, or form completion.
//
//
//------------------------------------------------------------------------------
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      routes: {
        '/two': (context) => const AudioState()
      },
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  void _incrementCounter() {
    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
    });
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'AudioPlayer',
          style: TextStyle(
              fontSize: 30,
              shadows: <Shadow>[
                Shadow(
                    offset: Offset(2.0, 2.0),
                    blurRadius: 3.0,
                    color: Colors.black
                ),
              ]
          ),
        ),
        centerTitle: true,
        toolbarHeight: 75,
        backgroundColor: Colors.black12,
      ),
      body: Center(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.
        child: Column(
          // Column is also a layout widget. It takes a list of children and
          // arranges them vertically. By default, it sizes itself to fit its
          // children horizontally, and tries to be as tall as its parent.
          //
          // Invoke "debug painting" (press "p" in the console, choose the
          // "Toggle Debug Paint" action from the Flutter Inspector in Android
          // Studio, or the "Toggle Debug Paint" command in Visual Studio Code)
          // to see the wireframe for each widget.
          //
          // Column has various properties to control how it sizes itself and
          // how it positions its children. Here we use mainAxisAlignment to
          // center the children vertically; the main axis here is the vertical
          // axis because Columns are vertical (the cross axis would be
          // horizontal).
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            OutlinedButton( // button that navigates to the second screen
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.black12),
                  shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                  elevation: MaterialStateProperty.all(5),
                ),
                onPressed: () {
                  Navigator.pushNamed(context, '/two'); // redirect to the second screen
                },
              child: Text("Press me to get started!",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    shadows: <Shadow>[
                      Shadow(
                          offset: Offset(2.0, 2.0),
                          blurRadius: 3.0,
                          color: Colors.black
                      ),
                    ]
                ),)
            )
          ],
        ),
      ),
    );
  }
}


class AudioState extends StatelessWidget { // class that handles utlizing the new packages
  const AudioState({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final AudioPlayer player = AudioPlayer();
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'AudioPlayer',
          style: TextStyle(
              color: Colors.white,
              fontSize: 30,
              shadows: <Shadow>[
                Shadow(
                    offset: Offset(2.0, 2.0),
                    blurRadius: 3.0,
                    color: Colors.black
                ),
              ]
          ),
        ),
        centerTitle: true,
        toolbarHeight: 75,
        backgroundColor: Colors.black12,
      ),

      backgroundColor: Colors.white,

      body: Center(


          child: Column( // contains all the buttons
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
            OutlinedButton( // button that plays the music
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.black12),
                  shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                  elevation: MaterialStateProperty.all(5),
                ),
            onPressed: ()  {
              Fluttertoast.showToast( // using the first new package, flutter toast
                msg: "Music is Playing!",
                toastLength: Toast.LENGTH_SHORT,
                backgroundColor: Colors.black38,
                fontSize: 18
              );
              player.setSourceAsset('sounds/chitarra.mp3'); // uses a free mp3 provided from https://pixabay.com/music/search/30%20sec/ and is written by nikproteus
              player.play(AssetSource('sounds/chitarra.mp3')); // using the second new package, audioplayers
              player.setVolume(1); // set the volume so it is heard clearly

              },
              child: Text(
                  'Press me to hear music!',
                style: TextStyle(
                    fontSize: 30,
                    color: Colors.white,
                    shadows: <Shadow>[
                      Shadow(
                          offset: Offset(2.0, 2.0),
                          blurRadius: 3.0,
                          color: Colors.black
                      ),
                    ]
                ),
              )
            ),
            OutlinedButton( // button used to pause the song
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(Colors.black12),
                shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                elevation: MaterialStateProperty.all(5),
              ),
                onPressed: () {
                  Fluttertoast.showToast( // using the first new package, flutter toast
                      msg: "Paused the Song!",
                      toastLength: Toast.LENGTH_SHORT,
                      backgroundColor: Colors.black38,
                      fontSize: 18
                  );
                  player.pause(); // using the second new package, audioplayers
                },
                child: Text(
                  'Pause the song',
                  style: TextStyle(
                      fontSize: 30,
                      color: Colors.white,
                      shadows: <Shadow>[
                        Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 3.0,
                            color: Colors.black
                        ),
                      ]
                  ),

                ),),
              OutlinedButton( // button used to resume the song if its been paused
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.black12),
                  shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                  elevation: MaterialStateProperty.all(5),
                ),
                onPressed: () {
                  Fluttertoast.showToast( // using the first new package, flutter toast
                      msg: "Song Resumed!",
                      toastLength: Toast.LENGTH_SHORT,
                      backgroundColor: Colors.black38,
                      fontSize: 18
                  );
                  player.resume(); // using the second new package, audioplayers
                },
                child: Text(
                    'Resume the song',
                  style: TextStyle(
                      fontSize: 30,
                      color: Colors.white,
                      shadows: <Shadow>[
                        Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 3.0,
                            color: Colors.black
                        ),
                      ]
                  ),
                ),),
              OutlinedButton( // button to the stop the song
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.black12),
                  shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                  elevation: MaterialStateProperty.all(5),
                ),
                onPressed: () {
                  Fluttertoast.showToast( // using the first new package, flutter toast
                      msg: "Song Stopped!",
                      toastLength: Toast.LENGTH_SHORT,
                      backgroundColor: Colors.black38,
                      fontSize: 18
                  );
                  player.stop(); // using the second new package, audioplayers
                },
                child: Text(
                    'Stop the song',
                  style: TextStyle(
                      fontSize: 30,
                      color: Colors.white,
                      shadows: <Shadow>[
                        Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 3.0,
                            color: Colors.black
                        ),
                      ]
                  ),
                ),)

        ]
      )
      )
    );
  }
}
