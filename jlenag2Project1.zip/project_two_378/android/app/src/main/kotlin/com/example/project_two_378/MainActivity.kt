package com.example.project_two_378

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
