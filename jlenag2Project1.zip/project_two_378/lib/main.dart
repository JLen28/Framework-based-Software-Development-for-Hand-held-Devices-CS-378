import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      routes: {
        '/second': (context) => const ChinaScreen(),
        '/secondTwo': (context) => const ChinaScreen2(),
        '/third': (context) => const MagScreen(),
        '/thirdTwo': (context) => const MagScreen2(),
        '/fourth': (context) => const LittleScreen(),
        '/fourthTwo':(context) => const LittleScreen2(),
        '/fifth':(context) => const LollaScreen(),
        '/fifthTwo':(context) => const LollaScreen2(),
        '/sixth':(context) => const PatsScreen(),
        '/sixthTwo':(context) => const PatsScreen2(),
        '/seventh':(context) => const BluesScreen(),
        '/seventhTwo':(context) => const BluesScreen2(),
        '/eighth':(context) => const CubsScreen(),
        '/eighthTwo':(context) => const CubsScreen2(),
        '/ninth':(context) => const BullsScreen(),
        '/ninthTwo':(context) => const BullsScreen2(),
        '/tenth':(context) => const FireScreen(),
        '/tenthTwo':(context) => const FireScreen2()

      },
      home: const MyHomePage(title: 'Welcome to Chicago'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;
  final List<Tab> myTabs = const <Tab>[ // creating the tabs to be grabbed by the tabBarView
    const Tab(text: 'NEIGHBORHOODS'),
    const Tab(text: 'EVENTS'),
    const Tab(text: 'SPORTS'),
  ];
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return DefaultTabController (
      length: 3,
      child: Scaffold(
      backgroundColor: Colors.deepPurpleAccent,

      appBar: AppBar(
        toolbarHeight: 70,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
          background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(55),
              top: Radius.circular(55),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title,
        style: const TextStyle( // adjust the style of the title of the app
          color: Colors.amber,
        )),
        bottom: TabBar( // grab the tabs we declared earlier and set them as the bottom of the appBar
          tabs: widget.myTabs,
          labelColor: Colors.amber, // adjusting the color of the tab labels
          splashBorderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15)
          )
        )
      ),

        body: TabBarView(
          children: widget.myTabs.map((Tab tab) {
            final String? label = tab.text;
            if(tab.text == "NEIGHBORHOODS"){ // check if we're in the 1st tab
              return Center(
                child: Column(

                    children: <Widget>[
                      const Padding( // padding between appbar and 1st button
                          padding: EdgeInsets.all(15)
                      ),
                      Row(
                          children: <Widget>[ // set of widgets for the chinatown row
                            Hero(
                                tag: 'neighbor1',
                                child: ElevatedButton(
                                    style: ButtonStyle( // style properties of the button
                                      fixedSize: MaterialStateProperty.all(Size(150,150)),
                                      backgroundColor: MaterialStateProperty.all<Color>(Colors.purple),
                                        shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                                        elevation: MaterialStateProperty.all(25),
                                        shape: MaterialStateProperty.all(const RoundedRectangleBorder(
                                          borderRadius: BorderRadius.vertical(
                                            bottom: Radius.circular(15),
                                            top: Radius.circular(15),
                                          ),
                                          side: BorderSide( // set the border color
                                            color: Colors.black,
                                          ),
                                        ),)
                                    ),
                                    onPressed: (){
                                      Navigator.pushNamed(context,'/second');
                                    },
                                    child: Image.asset('images/chinatown.jpg')
                                )),
                            const Padding(
                                padding: EdgeInsets.all(35)
                            ),
                            const Text( // set the name of the clickable button
                              'Chinatown',
                              style: TextStyle( // set the text style for button name
                                  fontSize: 20,
                                  color: Colors.amber
                              ),
                            ),
                          ]
                      ),
                      const Padding( // padding between 1st and 2nd button
                          padding: EdgeInsets.all(15)
                      ),
                      Row(
                          children: <Widget>[ // set of widgets for the magmile row
                            Hero(
                                tag: 'neighbor2',
                                child: ElevatedButton(
                                    style: ButtonStyle( // style properties of the button
                                      fixedSize: MaterialStateProperty.all(Size(150,150)),
                                      backgroundColor: MaterialStateProperty.all<Color>(Colors.purple),
                                        shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                                        elevation: MaterialStateProperty.all(25),
                                        shape: MaterialStateProperty.all(const RoundedRectangleBorder(
                                          borderRadius: BorderRadius.vertical(
                                            bottom: Radius.circular(15),
                                            top: Radius.circular(15),
                                          ),
                                          side: BorderSide( // set the border color
                                            color: Colors.black,
                                          ),
                                        ),)
                                    ),
                                    onPressed: (){
                                      Navigator.pushNamed(context,'/third');
                                    },
                                    child: Image.asset('images/magmile.jpg')
                                )),
                            const Padding(
                                padding: EdgeInsets.all(25)
                            ),
                            const Text( // set the name of the clickable button
                              'Magnificent Mile',
                              style: TextStyle( // set the text style for the buttons name
                                  fontSize: 20,
                                  color: Colors.amber),
                            ),
                          ]
                      ),
                      const Padding( // padding between 2nd and 3rd button
                          padding: EdgeInsets.all(15)
                      ),
                      Row(
                          children: <Widget>[ // set of widgets for the little village row
                            Hero(
                                tag: 'neighbor3',
                                child: ElevatedButton(
                                    style: ButtonStyle( // style properties of the button
                                      fixedSize: MaterialStateProperty.all(Size(150,150)),
                                      backgroundColor: MaterialStateProperty.all<Color>(Colors.purple),
                                        shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                                        elevation: MaterialStateProperty.all(25),
                                        shape: MaterialStateProperty.all(const RoundedRectangleBorder(
                                          borderRadius: BorderRadius.vertical(
                                            bottom: Radius.circular(15),
                                            top: Radius.circular(15),
                                          ),
                                          side: BorderSide( // set the border color
                                            color: Colors.black,
                                          ),
                                        ),)
                                    ),
                                    onPressed: (){
                                      Navigator.pushNamed(context,'/fourth');
                                    },
                                    child: Image.asset('images/littlevillage.jpg')
                                )),
                            const Padding(
                                padding: EdgeInsets.all(35)
                            ),
                            const Text( // set the name of the clickable button
                              'Little Village',
                              style: TextStyle( // set the text style for the buttons name
                                  fontSize: 20,
                                  color: Colors.amber
                              ),
                            ),
                          ]
                      ),
                    ]
                )
              );
            }
            else if(tab.text == "EVENTS"){ // not in the 1st tab, how about the second?
              return Center(
                  child: Column(
                      children: <Widget>[ // set of widgets for the lollapalooza row
                        const Padding( // padding between appbar and 1st button
                            padding: EdgeInsets.all(15)
                        ),
                        Row(
                        children: <Widget>[ // children of the row widget that contains the name and clickable image
                        Hero(
                          tag: 'event1',
                          child: ElevatedButton(
                            style: ButtonStyle( // style properties of the button
                              fixedSize: MaterialStateProperty.all(Size(150,150)),
                              backgroundColor: MaterialStateProperty.all<Color>(Colors.purple),
                                shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                                elevation: MaterialStateProperty.all(25),
                                shape: MaterialStateProperty.all(const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.vertical(
                                    bottom: Radius.circular(15),
                                    top: Radius.circular(15),
                                  ),
                                  side: BorderSide( // set the border color
                                    color: Colors.black,
                                  ),
                                ),)
                            ),
                            onPressed: (){
                              Navigator.pushNamed(context,'/fifth');
                            },
                             child: Image.asset('images/lollapalooza.jpg')
                        )),
                        const Padding(
                          padding: EdgeInsets.all(37)
                        ),
                        const Text( // set the name of the clickable button
                          'Lollapalooza',
                          style: TextStyle( // set the text style for the buttons name
                              fontSize: 20,
                              color: Colors.amber,
                          ),
                        ),
                        ]
                        ),
                        const Padding( // padding between 1st and 2nd button
                            padding: EdgeInsets.all(15)
                        ),
                        Row(
                            children: <Widget>[ // set of widgets for the st patricks day row
                              Hero(
                                  tag: 'event2',
                                  child: ElevatedButton(
                                      style: ButtonStyle( // style properties of the button
                                        fixedSize: MaterialStateProperty.all(Size(150,150)),
                                        backgroundColor: MaterialStateProperty.all<Color>(Colors.purple),
                                          shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                                          elevation: MaterialStateProperty.all(25),
                                          shape: MaterialStateProperty.all(const RoundedRectangleBorder(
                                            borderRadius: BorderRadius.vertical(
                                              bottom: Radius.circular(15),
                                              top: Radius.circular(15),
                                            ),
                                            side: BorderSide( // set the border color
                                              color: Colors.black,
                                            ),
                                          ),)
                                      ),
                                      onPressed: (){
                                        Navigator.pushNamed(context,'/sixth');
                                      },
                                      child: Image.asset('images/stpats.jpg')
                                  )),
                              const Padding(
                                  padding: EdgeInsets.all(32)
                              ),
                              const Text( // set the name of the clickable button
                                'St. Patricks Day',
                                style: TextStyle( // set the text style for the buttons name
                                    fontSize: 20,
                                    color: Colors.amber
                                ),
                              ),
                            ]
                        ),
                        const Padding( // padding between 2nd and 3rd button
                            padding: EdgeInsets.all(15)
                        ),
                        Row(
                            children: <Widget>[ // set of widgets for the chicago blues row
                              Hero(
                                  tag: 'event3',
                                  child: ElevatedButton(
                                      style: ButtonStyle( // style properties of the button
                                        fixedSize: MaterialStateProperty.all(Size(150,150)),
                                        backgroundColor: MaterialStateProperty.all<Color>(Colors.purple),
                                          shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                                          elevation: MaterialStateProperty.all(25),
                                          shape: MaterialStateProperty.all(const RoundedRectangleBorder(
                                            borderRadius: BorderRadius.vertical(
                                              bottom: Radius.circular(15),
                                              top: Radius.circular(15),
                                            ),
                                            side: BorderSide( // set the border color
                                              color: Colors.black,
                                            ),
                                          ),)
                                      ),
                                      onPressed: (){
                                        Navigator.pushNamed(context,'/seventh');
                                      },
                                      child: Image.asset('images/chicblues.jpg')
                                  )),
                              const Padding(
                                  padding: EdgeInsets.all(20)
                              ),
                              const Text( // set the name of the clickable button
                                'Chicago Blues Festival',
                                style: TextStyle( // set the text style for the buttons name
                                    fontSize: 20,
                                    color: Colors.amber
                                ),
                              ),
                            ]
                        ),
                      ]
                  )
              );
            }
            else { // not in the first or second tab, must be in the third tab
              return Center(
                  child: Column(
                      children: <Widget>[
                        const Padding( // padding between appbar and 1st button
                            padding: EdgeInsets.all(15)
                        ),
                        Row(
                            children: <Widget>[ // set of widgets for the chicago cubs row
                              Hero(
                                  tag: 'sport1',
                                  child: ElevatedButton(
                                      style: ButtonStyle( // style properties of the button
                                        fixedSize: MaterialStateProperty.all(Size(150,150)),
                                        backgroundColor: MaterialStateProperty.all<Color>(Colors.purple),
                                          shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                                          elevation: MaterialStateProperty.all(25),
                                          shape: MaterialStateProperty.all(const RoundedRectangleBorder(
                                            borderRadius: BorderRadius.vertical(
                                              bottom: Radius.circular(15),
                                              top: Radius.circular(15),
                                            ),
                                            side: BorderSide( // set the border color
                                              color: Colors.black,
                                            ),
                                          ),)
                                      ),
                                      onPressed: (){
                                        Navigator.pushNamed(context,'/eighth');
                                      },
                                      child: Image.asset('images/cubbies.jpg')
                                  )),
                              const Padding(
                                  padding: EdgeInsets.all(30)
                              ),
                              const Text( // set the name of the clickable button
                                'Chicago Cubs',
                                style: TextStyle( // set the text style for the buttons name
                                    fontSize: 20,
                                    color: Colors.amber
                                ),
                              ),
                            ]
                        ),
                        const Padding( // padding between 1st and 2nd button
                            padding: EdgeInsets.all(15)
                        ),
                        Row(
                            children: <Widget>[ // set of widgets for the chicago bulls row
                              Hero(
                                  tag: 'sport2',
                                  child: ElevatedButton(
                                      style: ButtonStyle( // style properties of the button
                                        fixedSize: MaterialStateProperty.all(Size(150,150)),
                                        backgroundColor: MaterialStateProperty.all<Color>(Colors.purple),
                                        shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                                        elevation: MaterialStateProperty.all(25),
                                          shape: MaterialStateProperty.all(const RoundedRectangleBorder(
                                            borderRadius: BorderRadius.vertical(
                                              bottom: Radius.circular(15),
                                              top: Radius.circular(15),
                                            ),
                                            side: BorderSide( // set the border color
                                              color: Colors.black,
                                            ),
                                          ),)

                                      ),
                                      onPressed: (){
                                        Navigator.pushNamed(context,'/ninth');
                                      },
                                      child: Image.asset('images/chibulls.jpg')
                                  )),
                              const Padding(
                                  padding: EdgeInsets.all(30)
                              ),
                              const Text( // set the name of the clickable button
                                'Chicago Bulls',
                                style: TextStyle( // set the text style for the buttons name
                                    fontSize: 20,
                                    color: Colors.amber
                                ),
                              ),
                            ]
                        ),
                        const Padding( // padding between 2nd and 3rd button
                            padding: EdgeInsets.all(15)
                        ),
                        Row(
                            children: <Widget>[ // set of widgets for the chicago fire row
                              Hero(
                                  tag: 'sport3',
                                  child: ElevatedButton(
                                      style: ButtonStyle( // style properties of the button
                                        fixedSize: MaterialStateProperty.all(const Size(150,150)),
                                        backgroundColor: MaterialStateProperty.all<Color>(Colors.purple),
                                          shadowColor: MaterialStateProperty.all<Color>(Colors.black),
                                          elevation: MaterialStateProperty.all(25),
                                          shape: MaterialStateProperty.all(const RoundedRectangleBorder(
                                            borderRadius: BorderRadius.vertical(
                                              bottom: Radius.circular(15),
                                              top: Radius.circular(15),
                                            ),
                                            side: BorderSide( // set the border color
                                              color: Colors.black,
                                            ),
                                          ),)
                                      ),
                                      onPressed: (){
                                        Navigator.pushNamed(context,'/tenth');
                                      },
                                      child: Image.asset('images/chifire.png')
                                  )),
                              const Padding(
                                  padding: EdgeInsets.all(35)
                              ),
                              const Text( // set the name of the clickable button
                                'Chicago Fire',
                                style: TextStyle( // set the text style for the buttons name
                                    fontSize: 20,
                                    color: Colors.amber
                                ),

                              ),
                            ]
                        ),
                      ]
                  )
              );
            }
          }).toList(),
        ),
      )
    );
  }
}
class ChinaScreen extends StatelessWidget {
  const ChinaScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
          toolbarHeight: 110,
          backgroundColor: Colors.deepPurple,

          flexibleSpace: FlexibleSpaceBar(
              background: Image.asset('images/skyline.jpeg')
          ),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(15),
              top: Radius.circular(15),
            ),
          ),
          // Here we take the value from the MyHomePage object that was created by
          // the App.build method, and use it to set our appbar title.
          title: const Text(
            "Chinatown",
              style: TextStyle( // adjust the style of the title of the app
                color: Colors.amber,
              )),
      ),
      body: Center(

        child: Column(
          children: <Widget>[
            Hero(
                tag: 'neighbor1',
                child: Image.asset('images/chinatown.jpg')
            ),
            const Text(
              "Chicago's neighborhood Chinatown",
                style: TextStyle( // adjust the style of the title of the app
                  color: Colors.amber,
                  fontSize: 20,
                )),
            const Padding(
                padding: EdgeInsets.all(5)
            ),
            const Text(
              'Located in the south side, centered on Cermak and Wentworth Avenues',
              style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
              fontSize: 20,
            )),
            const Padding(
                padding: EdgeInsets.all(5)
            ),
            const Text(
            "A prominent neighborhood in Chicago known for great food and great shops, Chinatown was first settled in 1912 and is home to roughly 16 thousand.",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
              fontSize: 20,
            )),
            const Padding(
                padding: EdgeInsets.all(45)
            ),
            FloatingActionButton(

              onPressed: (){
                Navigator.pushNamed(context,'/secondTwo');
              },
              backgroundColor: Colors.deepPurple,
              child: const Icon(Icons.add)
            )
          ]
        )
      ),
    );
  }
}

class ChinaScreen2 extends StatelessWidget {
  const ChinaScreen2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Chinatown",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[

                Image.asset('images/chinatowntwo.jpg'),

                const Text(
                    "Chicago's neighborhood Chinatown",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    "Many confuse Chinatown with Chicago's\n\" New Chinatown \", which is located on the northern side of Chicago.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(45)
                ),
                FloatingActionButton(
                    onPressed: (){
                      Navigator.popUntil(context, ModalRoute.withName('/second'));
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add_circle_outline)
                )
              ]
          )
      ),
    );
  }
}

class MagScreen extends StatelessWidget {
  const MagScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Magnificent Mile",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[
                Hero(
                    tag: 'neighbor2',
                    child: Image.asset('images/magmile.jpg')
                ),
                const Text(
                    "Chicago's neighborhood the Magnificent Mile",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    'Located in the near north side, running from the chicago river to the Oak street, the district is located within downtown.',
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    "One of Chicago's most recognizable neighborhoods home to the cities' largest shopping district as well as restaurants,musuems, and hotels.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(25)
                ),
                FloatingActionButton(

                    onPressed: (){
                      Navigator.pushNamed(context,'/thirdTwo');
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add)
                )
              ]
          )
      ),
    );
  }
}

class MagScreen2 extends StatelessWidget {
  const MagScreen2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Magnificent Mile",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[

                Image.asset('images/magmiletwo.jpg'),

                const Text(
                    "Chicago's neighborhood the Magnificent Mile",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(15)
                ),
                const Text(
                    "The name Magnificent Mile was coined in 1940s by a real estate developer known as Arthur Rubloff who worked for the Rubloff Company.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(45)
                ),
                FloatingActionButton(
                    onPressed: (){
                      Navigator.popUntil(context, ModalRoute.withName('/third'));
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add_circle_outline)
                )
              ]
          )
      ),
    );
  }
}

class LittleScreen extends StatelessWidget {
  const LittleScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Little Village",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[
                Hero(
                    tag: 'neighbor3',
                    child: Image.asset('images/littlevillage.jpg')
                ),
                const Text(
                    "Chicago's neighborhood Little Village",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    'One of South Lawndale\'s neighborhoods, located in the western and central areas of South Lawndale.',
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    "Often referred to as the \"Mexico of the Midwest\", was originally settled by Eastern European,Czech, and Bohemian immigrants.\n Eventually Chicano and Mexican residents came to reside in little village in the mid 60s due to segregation policies.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(10)
                ),
                FloatingActionButton(

                    onPressed: (){
                      Navigator.pushNamed(context,'/fourthTwo');
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add)
                )
              ]
          )
      ),
    );
  }
}

class LittleScreen2 extends StatelessWidget {
  const LittleScreen2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Little Village",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[

                Image.asset('images/littlevillagetwo.png'),

                const Text(
                    "Chicago's neighborhood Little Village",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(15)
                ),
                const Text(
                    "Pat Sajak, known for his time as a host for the show \"Wheel of Fortune\" grew up around the Little Village and South Lawndale area.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(45)
                ),
                FloatingActionButton(
                    onPressed: (){
                      Navigator.popUntil(context, ModalRoute.withName('/fourth'));
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add_circle_outline)
                )
              ]
          )
      ),
    );
  }
}

class LollaScreen extends StatelessWidget {
  const LollaScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Lollapalooza",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[
                Hero(
                    tag: 'event1',
                    child: Image.asset('images/lollapalooza.jpg')
                ),
                const Text(
                    "Chicago's famous music festival",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    'Located at Chicago\'s Grant park',
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    "One of, If not, the most popular music festival that Chicago has to offer,it got its start in 1991 as a touring event but eventually settled in Chicago as it's permanent home.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(50)
                ),
                FloatingActionButton(

                    onPressed: (){
                      Navigator.pushNamed(context,'/fifthTwo');
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add)
                )
              ]
          )
      ),
    );
  }
}

class LollaScreen2 extends StatelessWidget {
  const LollaScreen2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Lollapalooza",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[

                Image.asset('images/lollapaloozatwo.jpg'),

                const Text(
                    "Chicago's famous music festival",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(15)
                ),
                const Text(
                    "Lollapalooza was originally intended to be a farewell tour for the Perry Farrel and his Band \"Jane's Addiction\". Farrel says that he got the name for event after hearing the word in a Three Stooges film. ",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(45)
                ),
                FloatingActionButton(
                    onPressed: (){
                      Navigator.popUntil(context, ModalRoute.withName('/fifth'));
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add_circle_outline)
                )
              ]
          )
      ),
    );
  }
}

class PatsScreen extends StatelessWidget {
  const PatsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "St. Patrick's Day",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[
                Hero(
                    tag: 'event2',
                    child: Image.asset('images/stpats.jpg')
                ),
                const Text(
                    "Chicago's St. Patrick's Day Celebrations ",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    'Celebrations occur throughout the city,the most prominent being the parade that starts at Balbo and Columbus Drive.',
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    "A widely celebrated holiday in Chicago that involves a variety of festivities including the well known St. Patrick's Day parade.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(50)
                ),
                FloatingActionButton(

                    onPressed: (){
                      Navigator.pushNamed(context,'/sixthTwo');
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add)
                )
              ]
          )
      ),
    );
  }
}

class PatsScreen2 extends StatelessWidget {
  const PatsScreen2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "St. Patrick's Day",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[

                Image.asset('images/stpatstwo.jpg'),

                const Text(
                    "Chicago's St. Patrick's Day Celebrations ",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(15)
                ),
                const Text(
                    "The first St. Patrick's Day parade recorded was held in early 1890s! Shinnick's bar in Chicago has been open since this first parade and is still in operation to this day.  ",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(45)
                ),
                FloatingActionButton(
                    onPressed: (){
                      Navigator.popUntil(context, ModalRoute.withName('/sixth'));
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add_circle_outline)
                )
              ]
          )
      ),
    );
  }
}

class BluesScreen extends StatelessWidget {
  const BluesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Chicago Blues Festival",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[
                Hero(
                    tag: 'event3',
                    child: Image.asset('images/chicblues.jpg')
                ),
                const Text(
                    "Chicago's Celebration of the Blues",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    'The festival is held at 201 E. Randolph Street',
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    "A festival held at chicago's millennium park celebrating one of the oldest and most treasured musical styles.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(50)
                ),
                FloatingActionButton(

                    onPressed: (){
                      Navigator.pushNamed(context,'/seventhTwo');
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add)
                )
              ]
          )
      ),
    );
  }
}

class BluesScreen2 extends StatelessWidget {
  const BluesScreen2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Chicago Blues Festival",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[

                Image.asset('images/chicbluestwo.jpg'),

                const Text(
                    "Chicago's Celebration of the Blues",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(15)
                ),
                const Text(
                    "1984 was the first time the Chicago Blues Festival was held. Typically every year the organizers of the event choose a theme to honor a recently departed blues musician.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(45)
                ),
                FloatingActionButton(
                    onPressed: (){
                      Navigator.popUntil(context, ModalRoute.withName('/seventh'));
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add_circle_outline)
                )
              ]
          )
      ),
    );
  }
}

class CubsScreen extends StatelessWidget {
  const CubsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Chicago Cubs",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[
                Hero(
                    tag: 'sport1',
                    child: Image.asset('images/cubbies.jpg')
                ),
                const Text(
                    "Chicago's oldest baseball team",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    'The address for the Chicago Cubs is 1060 W. Addison St.',
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    "The elder of Chicago's two baseball team and the winner of the world series in 2016.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                FloatingActionButton(

                    onPressed: (){
                      Navigator.pushNamed(context,'/eighthTwo');
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add)
                )
              ]
          )
      ),
    );
  }
}

class CubsScreen2 extends StatelessWidget {
  const CubsScreen2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Chicago Cubs",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[

                Image.asset('images/cubbiestwo.jpg'),

                const Text(
                    "Chicago's oldest baseball team",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(15)
                ),
                const Text(
                    "The Cubs were formed in 1876 and would have three other titles before becoming the Cubs. First they were the White Stockings, then the Colts, and finally the Orphans.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(30)
                ),
                FloatingActionButton(
                    onPressed: (){
                      Navigator.popUntil(context, ModalRoute.withName('/eighth'));
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add_circle_outline)
                )
              ]
          )
      ),
    );
  }
}

class BullsScreen extends StatelessWidget {
  const BullsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Chicago Bulls",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[
                Hero(
                    tag: 'sport2',
                    child: Image.asset('images/chibulls.jpg')
                ),
                const Text(
                    "Chicago's prestigious Basketball Team",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    'The address for the Chicago Bulls is 1901 W. Madison St.',
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    "Chicago's well known Basketball team that was the home of some the greatest players in basketball history.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                FloatingActionButton(

                    onPressed: (){
                      Navigator.pushNamed(context,'/ninthTwo');
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add)
                )
              ]
          )
      ),
    );
  }
}

class BullsScreen2 extends StatelessWidget {
  const BullsScreen2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Chicago Bulls",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[

                Image.asset('images/chibullstwo.jpg'),

                const Text(
                    "Chicago's prestigious basketball team",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(15)
                ),
                const Text(
                    "The Chicago Bulls are one of the few teams and the first team in the NBA with over seventy wins in a single season. This occured during the '95-'96 season.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(30)
                ),
                FloatingActionButton(
                    onPressed: (){
                      Navigator.popUntil(context, ModalRoute.withName('/ninth'));
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add_circle_outline)
                )
              ]
          )
      ),
    );
  }
}

class FireScreen extends StatelessWidget {
  const FireScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Chicago Fire",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[
                Hero(
                    tag: 'sport3',
                    child: Image.asset('images/chifire.png')
                ),
                const Text(
                    "Chicago's finest soccer team",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    'The address for the Chicago Fire is 1 N. Dearborn St.',
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(5)
                ),
                const Text(
                    "The team holds a total of six titles with the most recent being from 2006 and plays on Soldier Field.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                FloatingActionButton(

                    onPressed: (){
                      Navigator.pushNamed(context,'/tenthTwo');
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add)
                )
              ]
          )
      ),
    );
  }
}

class FireScreen2 extends StatelessWidget {
  const FireScreen2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      appBar: AppBar(
        toolbarHeight: 110,
        backgroundColor: Colors.deepPurple,

        flexibleSpace: FlexibleSpaceBar(
            background: Image.asset('images/skyline.jpeg')
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
            top: Radius.circular(15),
          ),
        ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: const Text(
            "Chicago Fire",
            style: TextStyle( // adjust the style of the title of the app
              color: Colors.amber,
            )),
      ),
      body: Center(

          child: Column(
              children: <Widget>[

                Image.asset('images/chifiretwo.jpg'),

                const Text(
                    "Chicago's finest soccer team",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(15)
                ),
                const Text(
                    "The Chicago Fire soccer team has won a total of four U.S open cups, one of them during their first season which started in 1998.",
                    style: TextStyle( // adjust the style of the title of the app
                      color: Colors.amber,
                      fontSize: 20,
                    )),
                const Padding(
                    padding: EdgeInsets.all(30)
                ),
                FloatingActionButton(
                    onPressed: (){
                      Navigator.popUntil(context, ModalRoute.withName('/tenth'));
                    },
                    backgroundColor: Colors.deepPurple,
                    child: const Icon(Icons.add_circle_outline)
                )
              ]
          )
      ),
    );
  }
}